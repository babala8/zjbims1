import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '@env/environment';
import {Location} from '@angular/common';

@Injectable()
export class OrgService {

    private orgsUrl = `${environment.SERVER_URL}` + '/shepherd/system/org';

    constructor(private http: HttpClient,
                private location: Location) {
    }

    getOrgs(params): Observable<any> {
        return this.http.post<any>(this.orgsUrl + '/qryOrgs', params);
    }


    getOrg(orgNo): Observable<any> {
        return this.http.post<any>(this.orgsUrl + '/qryOrgByOrgId', {
            orgNo: orgNo
        });
    }

    addOrg(params): Observable<any> {
        return this.http.post<any>(this.orgsUrl + '/addOrg', params);
    }

    modOrg(params): Observable<any> {
        return this.http.post<any>(this.orgsUrl + '/modOrg', params);
    }

    delOrg(params): Observable<any> {
        return this.http.post<any>(this.orgsUrl + '/delOrg', params);
    }

    // qryAllOrgGrades(): Observable<any> {
    //     return this.http.post(this.orgsUrl + '/qryAllOrgTypes', {});
    // }

    getOrgTypesByGrade(orgGrade: string): Observable<any> {
        return this.http.post<any>(this.orgsUrl + '/qryOrgTypeByOrgGradeNo', {orgGrade: orgGrade});
    }

    getOrgTypesByOrgNo(orgNo: string): Observable<any> {
        return this.http.post<any>(this.orgsUrl + '/qryOrgTypesByOrgNo', {userOrgNo: orgNo});
    }

    getOrgType(params): Observable<any> {
        return this.http.post<any>(this.orgsUrl + '/qryAllOrgTypes', {});
    }

    back() {
        this.location.back();
    }

}

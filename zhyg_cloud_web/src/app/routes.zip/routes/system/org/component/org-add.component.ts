import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {OrgService} from '../org.service';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {CITIES, REGIONS} from '../../../../core/constant';

import {Org} from '../../../../models/org';
import {HttpResponse} from '@angular/common/http';
import {SessionService} from '@core/session.service';
import {OrgType} from '../../../../models/orgType';
import {Router} from '@angular/router';

@Component({
    templateUrl: './org-add.html'
})
export class OrgAddComponent implements OnInit {

    validateForm: FormGroup;
    orgGrade;
    orgTypeList: OrgType[] = [];
    loading = false;
    regions = REGIONS;
    cities = [];
    i = 0;
    org = new Org();
    showFlag = 0;

    constructor(private fb: FormBuilder,
                private orgService: OrgService,
                private nzModal: NzModalSubject,
                private session: SessionService,
                private message: NzMessageService,
                private router: Router) {
    }

    /**
     * 选择上级机构后，查询用户可选的机构类型列表
     * @param evt
     */
    selectOrg(evt: any) {
        console.log(evt);
        const orgNo = evt.no;
        if (orgNo) {
            this.orgService.getOrg(orgNo)
                .subscribe(_data => {
                        this.org = _data;
                        console.log('grade1: ' + this.org.orgGrade);
                        if (this.org.orgGrade === '6') {
                            this.message.error('所选机构不允许作为上级机构!', {nzDuration: 10000});
                        } else {
                            this.orgService.getOrgTypesByGrade(this.org.orgGrade).subscribe(
                                data => {
                                    this.loading = false;
                                    for ( this.i = 0; this.i < data.retList.length; (this.i)++) {
                                        if ((Number(data.retList[this.i].grade)) === (Number(this.org.orgGrade) + 1)) {
                                            data.retList.splice((Number(this.i) + 1), ((Number(data.retList.length)) - (Number(this.i))));
                                        }
                                    }
                                    this.orgTypeList = data.retList;
                                },
                                error => {
                                    this.loading = false;
                                    this.message.error(error.body.retMsg);
                                }
                            );
                        }
                    }
                );
        }
    }

    _submitForm() {
        for (const i in this.validateForm.controls) {
             if (this.validateForm.controls[i]) {
                 this.validateForm.controls[i].markAsDirty();
             }
         }

        if (this.validateForm.invalid) {
            return;
        }
        const params = {
            orgNo: this.validateForm.controls.no.value,
            orgName: this.validateForm.controls.name.value,
            parentOrg: this.validateForm.controls.upper.value.no || '',
            orgType: this.validateForm.controls.orgType.value || '',
            address: this.validateForm.controls.address.value || '',
        };

        console.log(params);
        this.loading = true;
        this.orgService.addOrg(params)
            .subscribe(_data => {
                this.loading = false;
                this.message.success(`添加机构成功！`);
                this.nzModal.destroy('onOk');
                this.router.navigate(['/system/org']);
            }, (error) => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    regionChange(region) {
        console.log(region);
        // this.validateForm.controls.city.setValue(null);
        for (const r of this.regions) {
            if (r.name === region) {
                this.cities = CITIES[r.no];
            }
        }
    }

    /**
     * 初始化表单
     */
    ngOnInit() {
        this.validateForm = this.fb.group({
            no: [null, [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
            name: [null, [Validators.required, Validators.maxLength(20)]],
            upper: [null],
            orgType: [null],
            address: [null, [Validators.maxLength(200)]],
        });
    }

    /**
     * 根据字段名获取表单字段值
     * @param name
     */
    getFormControl(name) {
        return this.validateForm.controls[name];
    }

    updateConfirmValidator() {
        setTimeout(() => {
            this.validateForm.controls['name'].updateValueAndValidity();
        });
    }

    cancel() {
        this.nzModal.destroy('onCancel');
    }

}


import {Component, OnInit} from '@angular/core';
import { FormControl } from '@angular/forms';
import {OrgService} from '../org.service';
import {Org} from '../../../../models/org';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {REGIONS} from '../../../../core/constant';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {HttpResponse} from '@angular/common/http';
import {SessionService} from '@core/session.service';
import {ActivatedRoute, Router} from '@angular/router';
import {OrgType} from '../../../../models/orgType';

@Component({
    templateUrl: './org-modify.html'
})
export class OrgModifyComponent implements OnInit {


    validateForm: FormGroup;
    orgs;
    org: Org;
    loading = false;
    showFlag = 0;
    tmp;
    upper = '';
    i = 0;
    orgTypeList: OrgType[] = [];
    // 临时存放机构类型
    temp_orgType;
    // 临时存放父机构
    temp_parentOrg;

    constructor(private fb: FormBuilder,
                private orgService: OrgService,
                private nzModal: NzModalSubject,
                private session: SessionService,
                private message: NzMessageService,
                private route: ActivatedRoute,
                private router: Router) {

    }


    ngOnInit(): void {
        // 初始化表单

        this.validateForm = this.fb.group({
            no: [null, [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
            name: [null, [Validators.required, Validators.maxLength(20)]],
            upper: [null],
            address: [null, Validators.maxLength(200)],
            orgType: [null]
        });

        this.tmp = [
            {
                no: '',
                name: ''
            }
        ]

        // 获取机构详细信息
        this.loading = true;
        this.orgService.getOrg(this.orgs.no).subscribe(
            data => {
                this.loading = false;
                console.log(data);
                this.org = data;
                this.validateForm.controls.no.setValue(this.org.no);
                this.validateForm.controls.name.setValue(this.org.name);
                if (this.org.parentOrgNo) {
                    // 机构树的value是{no: orgNo, name: orgName}格式
                    this.validateForm.controls.upper.setValue({
                        no: this.org.parentOrgNo,
                        name: data.parentOrgName
                    } || {});
                } else {
                    // 总行没有上级机构，因此上级机构为自己
                    this.validateForm.controls.upper.setValue({
                        no: '',
                        name: ''
                    });
                }
                // 为机构树赋值后会触发监听方法，查询机构类型后刷新机构类型字段
                // this.validateForm.controls.orgType.setValue({
                //     no: this.org.orgType,
                //     name: this.org.orgTypeName
                // } || {});
                this.validateForm.controls.orgType.setValue(this.org.orgType || '');
                this.validateForm.controls.address.setValue(this.org.address || '');
            },
            error => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    _submitForm() {
        for (const i in this.validateForm.controls) {
            if (this.validateForm.controls[i]) {
                this.validateForm.controls[i].markAsDirty();
            }
        }

        if (this.validateForm.invalid) {
            return;
        }
        const params = {
            address: this.validateForm.controls.address.value,
            orgName: this.validateForm.controls.name.value,
            orgNo: this.validateForm.controls.no.value,
            orgType: this.validateForm.controls.orgType.value,
            parentOrg: this.validateForm.controls.upper.value.no,
        };
        this.loading = true;
        this.orgService.modOrg(params)
            .subscribe(data => {
                this.loading = false;
                this.message.success('修改机构成功！');
                this.nzModal.destroy('onOk');
                this.router.navigate(['/system/org']);
            }, (error) => {
                this.loading = false;
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    getFormControl(name) {
        return this.validateForm.controls[name];
    }

    updateConfirmValidator() {
        setTimeout(() => {
            this.validateForm.controls['name'].updateValueAndValidity();
        });
    }

    selectOrg(evt: any) {
        console.log(evt);
        const orgNo = evt.no;
        if (orgNo) {
            this.orgService.getOrg(orgNo)
                .subscribe(_data => {
                        this.org = _data;
                        console.log('grade1: ' + this.org.orgGrade);
                        if (this.org.orgGrade === '6') {
                            this.message.error('所选机构不允许作为上级机构!', {nzDuration: 10000});
                        } else {
                            this.orgService.getOrgTypesByGrade(this.org.orgGrade).subscribe(
                                data => {
                                    this.loading = false;
                                    for ( this.i = 0; this.i < data.retList.length; (this.i)++) {
                                        if ((Number(data.retList[this.i].grade)) === (Number(this.org.orgGrade) + 1)) {
                                            data.retList.splice((Number(this.i) + 1), ((Number(data.retList.length)) - (Number(this.i))));
                                        }
                                    }
                                    this.orgTypeList = data.retList;
                                },
                                error => {
                                    this.loading = false;
                                    this.message.error(error.body.retMsg);
                                }
                            );
                        }
                    }
                );
        }
    }

    cancel() {
        this.nzModal.destroy('onCancel');
    }

}

import {Component, OnInit} from '@angular/core';
import {OrgService} from '../org.service';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {Org} from '../../../../models/org';
import {HttpResponse} from '@angular/common/http';

@Component({
    templateUrl: './org-detail.html',
})
export class OrgDetailComponent implements OnInit {

    formModel = {};
    orgs;
    org = new Org();
    loading = false;

    constructor(
        private orgService: OrgService,
        private nzModal: NzModalSubject,
        private message: NzMessageService,
    ) {
    }

    ngOnInit() {

        this.orgService.getOrg(this.orgs.no).subscribe(
            data => {
                this.loading = false;
                console.log(data);
                this.formModel['no'] = data.no;
                this.formModel['name'] = data.name;
                this.formModel['upper'] = data.parentOrgName;
                this.formModel['orgType'] = data.orgTypeName;
                this.formModel['address'] = data.address;
            },
            error => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    cancel() {
        this.nzModal.destroy('onCancel');
    }

}

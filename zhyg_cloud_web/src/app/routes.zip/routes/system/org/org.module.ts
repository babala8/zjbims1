import {NgModule} from '@angular/core';
import {SharedModule} from '../../../shared/shared.module';
import {OrgComponent} from './org.component';
import {OrgService} from './org.service';
import {OrgAddComponent} from './component/org-add.component';
import {OrgModifyComponent} from './component/org-modify.component';
import {OrgDetailComponent} from './component/org-detail.component';
import {SystemRoutingModule} from '../system.routing';

@NgModule({
    imports: [
        SharedModule,
        SystemRoutingModule,
    ],
    declarations: [
        OrgComponent,
        OrgAddComponent,
        OrgModifyComponent,
        OrgDetailComponent
    ],
    entryComponents: [
        OrgAddComponent,
        OrgModifyComponent,
        OrgDetailComponent
    ],
    providers: [
        OrgService
    ]
})
export class OrgModule {

}

import {Component, OnInit, TemplateRef, OnChanges} from '@angular/core';
import {OrgService} from './org.service';
import {Router} from '@angular/router';
import {Org} from '../../../models/org';
import {NzMessageService, NzModalService} from 'ng-zorro-antd';
import {Page} from '../../../models/page';
import {SessionService} from '@core/session.service';
import {HttpResponse} from '@angular/common/http';
import {FormBuilder, FormGroup} from '@angular/forms';
import {OrgType} from '../../../models/orgType';
import {OrgAddComponent} from './component/org-add.component';
import {OrgModifyComponent} from './component/org-modify.component';
import {OrgDetailComponent} from './component/org-detail.component';
import {UserAddComponent} from '../user/component/user-add.component';
import {SysMenuService} from '../menu/menu.service';

@Component({
    templateUrl: './org.html',
})
export class OrgComponent implements OnInit {

    formModel = {};
    validateForm: FormGroup;
    dataSet = [];
    i = 0;
    orgGrade;
    orgTypeList: OrgType[] = [];
    loading = true;
    org: Org;
    page = new Page();

    constructor(
        private session: SessionService,
        private fb: FormBuilder,
        private orgService: OrgService,
        private modal: NzModalService,
        private menuService: SysMenuService,
        private message: NzMessageService
    ) {
    }

    ngOnInit() {
        this.validateForm = this.fb.group({
            orgNo: [null],
            orgType: [null],
            upper: [
                {no: '', name: ''}]
        });
        this.refreshData(true);
    }

    refreshData(reset = false) {
        if (reset) {
            this.page.curPage = 1;
        }
        const params = {
            orgNo: this.validateForm.controls.orgNo.value || '',
            userOrgNo: this.session.getUserSession().orgNo || '',
            orgType: this.validateForm.controls.orgType.value || '',
            upper: this.validateForm.controls.upper.value.no || '',
            curPage: this.page.curPage,
            pageSize: this.page.pageSize,
        };
        console.log(params);
        this.loading = true;
        // 获取当前页
        this.orgService.getOrgs(params)
            .subscribe(data => {
                console.log(data);
                this.loading = false;
                // 将父机构编号转换为名称
                for (const x of data.orgInfo) {
                    if (!x.parentOrg) {
                        continue;
                    }
                    for (const i of data.parentOrgInfo) {
                        if (i.no === x.parentOrg) {
                            x.parentOrg = i.name;
                            break;
                        }
                    }
                }
                this.dataSet = data.orgInfo;
                this.page.totalRow = data['totalRow'];
            }, (error) => {
                this.loading = false;
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    addOrg() {
        const modal = this.modal.open({
            title: '添加机构',
            maskClosable: false,
            footer: false,
            content: OrgAddComponent,
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

    modifyOrg(orgs) {
        const modal = this.modal.open({
            title: '修改机构',
            maskClosable: false,
            footer: false,
            content: OrgModifyComponent,
            componentParams: {
                orgs: orgs
            },
            onOk: () => {
                this.refreshData(false);
            },
            onCancel: () => {
            },
        });
    }

    openDetail(orgs) {
        const modal = this.modal.open({
           title: '机构详情',
           maskClosable: false,
           footer: false,
           width: '60%',
           content: OrgDetailComponent,
           componentParams: {
               orgs: orgs
           },
           onOk: () => {
               this.refreshData(false);
           },
           onCancel: () => {
           },
        });
    }

    confirmDel(orgNo) {
        this.orgService.delOrg({
            orgNo: orgNo
        }).subscribe(data => {
            this.refreshData(false);
            this.message.success('删除机构成功');
            this.refreshData(false);
        }, (error) => {
            console.log(error);
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    /**
     * 选择上级机构后，查询用户可选的机构类型列表
     * @param evt
     */
    selectOrg(evt: any) {
        const orgNo = evt.no;
        if (orgNo) {
            this.orgService.getOrg(orgNo)
                .subscribe(_data => {
                        this.org = _data;
                        if (this.org.orgGrade === '6') {
                            this.message.error('所选机构不允许作为上级机构!', {nzDuration: 10000});
                        } else {
                            console.log(this.org.orgGrade);
                            this.orgService.getOrgTypesByGrade(this.org.orgGrade).subscribe(
                                data => {
                                    for ( this.i = 0; this.i < data.retList.length; (this.i)++) {
                                        if ((Number(data.retList[this.i].grade)) === (Number(this.org.orgGrade) + 1)) {
                                            data.retList.splice((Number(this.i) + 1), ((Number(data.retList.length)) - (Number(this.i))));
                                        }
                                    }
                                    this.orgTypeList = data.retList;
                                },
                                error => {
                                    this.message.error(error.body.retMsg);
                                }
                            );
                        }
                    }
                );
        }
    }

    /**
     * 重置查询条件
     *
     */
    reset() {
        this.validateForm.reset();
        this.validateForm.controls.orgNo.setValue('');
        this.validateForm.controls.upper.setValue({});
        this.validateForm.controls.orgType.setValue('');
        this.orgTypeList = [];
        this.refreshData(true);
    }

    cancel() {

    }

    /**
     * 校验按钮权限
     * @param menuName
     * @param btnName
     */
    checkBtn(menuName: string, btnName: string): boolean {
        return this.menuService.checkBtn(menuName, btnName);
    }


}

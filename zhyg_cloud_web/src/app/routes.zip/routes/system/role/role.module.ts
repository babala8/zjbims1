import {NgModule} from '@angular/core';
import {RoleService} from './role.service';
import {RoleComponent} from './role.component';
import {SharedModule} from '../../../shared/shared.module';
import {RoleAddComponent} from './component/role-add.component';
import {RoleModifyComponent} from './component/role-modify.component';
import {RoleDetailComponent} from './component/role-detail.component';
import {SystemRoutingModule} from '../system.routing';

@NgModule({
    imports: [
        SharedModule,
        SystemRoutingModule
    ],
    declarations: [
        RoleComponent,
        RoleAddComponent,
        RoleModifyComponent,
        RoleDetailComponent
    ],
    entryComponents: [
        RoleAddComponent,
        RoleModifyComponent,
        RoleDetailComponent
    ],
    providers: [
        RoleService
    ]
})
export class RoleModule {

}





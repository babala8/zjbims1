import {Component, OnInit, TemplateRef, OnChanges} from '@angular/core';
import {RoleService} from './role.service';
import {Page} from '../../../models/page';
import {NzMessageService, NzModalService} from 'ng-zorro-antd';
import {RoleAddComponent} from './component/role-add.component';
import {RoleModifyComponent} from './component/role-modify.component';
import {RoleDetailComponent} from './component/role-detail.component';
import {SessionService} from '../../../core/session.service';
import {ORGGRADES, RET_CODE} from '@core/constant';
import {HttpResponse} from '@angular/common/http';
import {OrgService} from '../org/org.service';
import {SysMenuService} from '../menu/menu.service';

@Component({
    templateUrl: './role.html',

})
export class RoleComponent implements OnInit {

    formModel = {};
    dataSet = [];
    loading = false;
    page = new Page();
    userOrgTypeNo: any;

    orgGrades = ORGGRADES;

    constructor(private roleService: RoleService,
                private orgService: OrgService,
                private session: SessionService,
                private message: NzMessageService,
                private menuService: SysMenuService,
                private modal: NzModalService) {
    }


    ngOnInit() {
        this.refreshData(true);
    }

    refreshData(reset = false) {
        if (reset) {
            this.page.curPage = 1;
        }
        this.loading = true;

        // TODO:  合并 this.page 与 this.formModel对象

        console.log(this.formModel);
        // 合并 this.page 与 this.formModel对象
        const orgNo = this.session.getUserSession().orgNo;
        this.orgService.getOrgTypesByOrgNo(orgNo)
            .subscribe(_data => {
            this.orgGrades = _data['retList'];
        }, (error) => {
            console.log(error);
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });

        console.log('......................>' + this.page.curPage);
        const params = {
            orgTypeNo: this.formModel['orgTypeNo'] || '',
            userOrgNo: this.session.getUserSession().orgNo,
            roleName: this.formModel['roleName'] || '',
            // userOrgTypeNo未使用
            userOrgTypeNo: '11',
            curPage: this.page.curPage,
            pageSize: this.page.pageSize || '20',
            curRow: this.page.curRow || '',
            totalPage: this.page.totalPage || '',
            totalRow: this.page.totalRow || '',
        };
        console.log('查询角色' + params);
        this.roleService.qryRolesByPages(params)
            .subscribe(_data => {
                console.log('查询角色' + _data);
                this.dataSet = _data['retList'];
                this.page.totalRow = _data['totalRow'];
                this.loading = false;
            }, (error) => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    search() {
        this.refreshData(true);
        console.log(this.formModel);
    }

    delRole(item) {
        console.log('delete role!');
        this.loading = true;
        this.roleService.delRole(item).subscribe(r => {
                this.loading = false;
                this.message.success(`角色已删除！`);
                this.refreshData(true);

            }, (error) => {
                console.log(error);
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
    }

    modRole(role) {
        console.log(role);
        const modal = this.modal.open({
            title: '修改角色',
            maskClosable: false,
            footer: false,
            content: RoleModifyComponent,
            componentParams: {
                role: role
            },
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

    addRole() {
        const modal = this.modal.open({
            title: '添加角色',
            maskClosable: false,
            footer: false,
            content: RoleAddComponent,
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

    showDetail(role) {
        const modal = this.modal.open({
            title: '角色详细信息',
            footer: false,
            maskClosable: false,
            content: RoleDetailComponent,
            componentParams: {
                role: role
            },
            onOk: () => {
            },
            onCancel: () => {
            },
        });
    }

    /**
     * 校验按钮权限
     * @param menuName
     * @param btnName
     */
    checkBtn(menuName: string, btnName: string): boolean {
        return this.menuService.checkBtn(menuName, btnName);
    }

}

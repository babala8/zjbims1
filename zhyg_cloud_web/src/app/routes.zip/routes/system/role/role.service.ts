import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {environment} from '@env/environment';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class RoleService {

    private roleUrl = `${environment.SERVER_URL}` + '/shepherd/system/role';

    constructor(private http: HttpClient) {

    }


    qryRolesByPages(params): Observable<any> {
        return this.http.post(this.roleUrl + '/qryRolesByPages', params);
    }

    qryAllUsers(): Observable<any> {
        return this.http.post(this.roleUrl + '/qryAllUsers', '');
    }

    qryRoleByOrgType(params): Observable<any> {
        return this.http.post(this.roleUrl + '/qryRoleByOrgType', params);
    }

    qryAvailableRoleByOrgNo(params): Observable<any> {
        return this.http.post(this.roleUrl + '/qryAvailableRoleByOrgNo', params);
    }

    addRole(params): Observable<any> {
        return this.http.post(this.roleUrl + '/addRole', params);
    }

    modRole(params): Observable<any> {
        return this.http.post(this.roleUrl + '/modRole', params);
    }

    delRole(role): Observable<any> {
        return this.http.post(this.roleUrl + '/delRole', {
            roleNo: role
        });
    }

    // 查询所有菜单
    qryAllMenus(): Observable<any> {
        return this.http.post(`${environment.SERVER_URL}` + '/shepherd/system/menu/qryAllMenus', '');
    }

    qryMenuByRoleid(roleNo): Observable<any> {
        return this.http.post(this.roleUrl + '/qryMenuByRoleid', {
            roleNo: roleNo
        });
    }


    qryRoleById(roleNo): Observable<any> {
        return this.http.post(this.roleUrl + '/qryRoleById', {
            roleNo: roleNo
        });
    }

}


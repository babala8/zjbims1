import {Component, OnInit, ViewChild} from '@angular/core';
import {ORGGRADES} from '../../../../core/constant';
import {RoleService} from '../role.service';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {ITreeOptions, ITreeState, TreeComponent, TreeNode} from 'angular-tree-component';
// import * as _ from 'lodash';
import {SessionService} from '../../../../core/session.service';
import {HttpResponse} from '@angular/common/http';
import {SysMenuService} from '../../menu/menu.service';

@Component({
    templateUrl: './role-add.html',
})
export class RoleAddComponent implements OnInit {

    _isSpinning = true;
    formModel = {};
    grades = ORGGRADES;
    _selectedMenu;
    _selectedButton;
    loading = false;
    @ViewChild(TreeComponent) tree: TreeComponent;
    nodes1: any;
    options: ITreeOptions = {
        displayField: 'text',
        nodeHeight: 15,
        useCheckbox: true,
    };

    treeState: ITreeState;

    constructor(private roleService: RoleService,
                private service: SysMenuService,
                private nzModal: NzModalSubject,
                private session: SessionService,
                private message: NzMessageService) {
    }

    private _menuTree;


    ngOnInit() {
        this.nodes1 = [];
        this.service.getMenus().subscribe(data => {
            this.nodes1 = data[0].children;
            console.log(data);
            this._isSpinning = false;
        });
    }

    get nodes() {
        return this._menuTree && this._menuTree[0].children;
    }

    _submitForm() {
        this._selectedMenu = [];
        this._selectedButton = [];
        this.loopNode(this.nodes1);

         const params = $.extend({
             data: {
                 no: this.formModel['no'],
                 roleName: this.formModel['name'],
                 catalog: '2',
                 orgType: this.formModel['orgType'],
                 note: this.formModel['note'],
             },
             menu: this._selectedMenu,
             button: this._selectedButton
         }, {});
         this.loading = true;
         this.roleService.addRole(params)
             .subscribe(_data => {
                 this.loading = false;
                 this.nzModal.destroy('onOk');
                 this.message.success(`增加角色成功！`);
             }, (error) => {
                 this.loading = false;
                 console.log(error);
                 if (error instanceof HttpResponse) {
                     this.message.error(error.body.retMsg);
                 }
             });

    }

    loopNode(nodes: Array<any>) {
        nodes.forEach((node) => {
            if (node.checked) {
                node.id && (this._selectedMenu.indexOf(node.id) === -1) && this._selectedMenu.push(node.id);
            }

            if (node.children) {
                this.loopNode(node.children);
            }
            // if (node.isSelected) {
            //     node.data.serverID && this._selectedMenu.indexOf(node.data.serverID) === -1 && this._selectedMenu.push(node.data.serverID);
            //     if (node.children) {
            //         this.loopNode(node.children);
            //     }
            // }
        });
    }

    cancel() {
        this.nzModal.destroy('onCancel');
    }
}

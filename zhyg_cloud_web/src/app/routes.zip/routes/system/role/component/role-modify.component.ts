import {Component, OnInit, ViewChild} from '@angular/core';
import {RoleService} from '../role.service';
import {ITreeOptions, ITreeState, TreeComponent} from 'angular-tree-component';
import {ORGGRADES} from '@core/constant';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import * as _ from 'lodash';
import {SessionService} from '@core/session.service';
import {HttpResponse} from '@angular/common/http';
import {environment} from '@env/environment';
import {_HttpClient} from '@zjft/theme';
import {NzTreeComponent} from '@zjft/ng-tree-antd';
import {SysMenuService} from '../../menu/menu.service';
import {forEach} from '@angular/router/src/utils/collection';

@Component({
    templateUrl: './role-modify.html'
})
export class RoleModifyComponent implements OnInit {
    _isSpinning = true;
    grades = ORGGRADES;
    formModel = {};
    role;
    nodes = [];
    treeState;
    _selectedMenu;
    loading = false;
    // 菜单信息以及按钮信息
    btnMenu = [];
    // 显示按钮分配开关
    showButtons = false;
    // 当前菜单的按钮组
    _buttons = [];
    // 保存按钮选择结果
    _selectedButton = [];

    @ViewChild(NzTreeComponent) tree: NzTreeComponent;
    options: ITreeOptions = {
        displayField: 'text',
        animateExpand: true,
        animateAcceleration: 6,
        nodeHeight: 15,
        useCheckbox: true,
    };

    tableData = [
        {name: 'name', desc: 'desc'}
    ];


    constructor(private roleService: RoleService,
                private service: SysMenuService,
                private httpClient: _HttpClient,
                private nzModal: NzModalSubject,
                private session: SessionService,
                private message: NzMessageService) {

    }

    ngOnInit() {
        // 获取所有菜单，构建菜单树
        // this.httpClient.post(`${environment.SERVER_URL}` + 'visible/dashBoardManage/qryParamInfos', {
        //    type: 'menu'
        // }).subscribe((_data: any) => {
        // this.roleService.qryAllMenus().subscribe((_data: any) => {
        //    if (_data.retList.length > 0) {
        //        // 菜单json展示
        //        const nodes = JSON.parse(_data.retList[0].content);
        //        this.nodes = nodes[0].children;
        //    }
        this.service.getMenus().subscribe(data => {
            this.nodes = data[0].children;
            this.service.getButtons().subscribe(data2 => {
                    // @ts-ignore
                    this.btnMenu = this.mergeButtonsByMenu(data2.btnList);
                    // 获取当前角色关联的菜单，设置菜单树的初始状态
                    this.roleService.qryMenuByRoleid(this.role.no)
                        .subscribe(_data => {
                            this.treeState = {
                                expandedNodeIds: {},
                                activeNodeIds: {},
                                selectedLeafNodeIds: {}
                            };
                            this._isSpinning = false;

                            const array1 = [];  // 已选择的ids

                            _data.retList = _data.SysRoleMune.menus.map(value => value.no);
                            this._selectedButton = _data.SysRoleMune.buttons ? _data.SysRoleMune.buttons.map(value => value.no) : [];

                            const loop = (array) => {
                                array.forEach(value => {
                                    if (_data.retList.includes(value.id)) {
                                        value.checked = true;
                                        array1.push(value.id);
                                    }
                                    if ($.isArray(value.children)) {
                                        loop(value.children);
                                    }
                                });
                            };
                            loop(this.nodes);
                            console.log(this.nodes);

                            // this.loopMenu(array1);
                            // this.expandTree();
                            this._isSpinning = false;
                            this.formModel['no'] = _data.SysRoleMune.no;
                            this.formModel['name'] = _data.SysRoleMune.name;
                            this.formModel['note'] = _data.SysRoleMune.note;
                            this.formModel['orgType'] = _data.SysRoleMune.orgType + '';
                        });
                }
            );
        });
    }

    _submitForm() {
        this._selectedMenu = [];
        this.loopNode(this.nodes);
        this.processBtn();
        const params = {
            roleNo: this.formModel['no'],
            data: {
                no: this.formModel['no'],
                name: this.formModel['name'],
                catalog: '2',
                orgType: this.formModel['orgType'],
                bforeRoelName: '',
                note: this.formModel['note'],
            },
            menu: this._selectedMenu,
            button: this._selectedButton
        };
        this.loading = true;
        this.roleService.modRole(params).subscribe(data => {
            this.loading = false;
            this.nzModal.destroy('onOk');
            this.message.success(`修改角色成功！`);
        }, (error) => {
            this.loading = false;
            console.log(error);
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });

    }

    checkAll() {
        const loop = nodes => {
            nodes.forEach(node => {
                if (!node.children) {
                    this.tree.treeModel.setSelectedNode(node, true);
                } else {
                    loop(node.children);
                }
            });
        };
        loop(this.tree.treeModel.roots);
    }

    uncheckAll() {
        this.tree.treeModel.setState(true);
    }

    collapseTree() {
        this.tree.treeModel.collapseAll();
    }

    expandTree() {
        this.tree.treeModel.expandAll();
    }


    loopMenu(menus: Array<any>) {
        menus.forEach(value => {
            console.log(value);
            this.treeState.selectedLeafNodeIds[value] = true;
        });
        console.log(this.nodes);
        console.log(this.tree.treeModel);
        console.log(this.tree.treeModel.setState(this.treeState));
    }

    loopNode(nodes: Array<any>) {
        nodes.forEach((node) => {

            // if (node.isSelected) {
            //     node.data.serverID && (this._selectedMenu.indexOf(node.data.serverID) === -1) && this._selectedMenu.push(node.data.serverID);
            // }

            if (node.checked) {
                if (node.id && (this._selectedMenu.indexOf(node.id) === -1)) {
                    this._selectedMenu.push(node.id);
                }
            }

            if (node.children) {
                this.loopNode(node.children);
            }
        });
    }

    /**
     * 去除未选择的菜单下的按钮
     */
    private processBtn() {
        const unselectedMenu = this.btnMenu.filter(x => !this._selectedMenu.includes(x.menuNo));
        const unselectedBtn = [];
        unselectedMenu.forEach(x => {
            x.buttons.forEach(y => {
                unselectedBtn.push(y.btnNo);
            })
        });
        this._selectedButton = this._selectedButton.filter(x => !unselectedBtn.includes(x));
    }

    /**
     * 根据菜单归类按钮
     * @param buttons
     */
    private mergeButtonsByMenu(buttons): {}[] {
        const result: { menuNo: string, menuName: string, buttons: { btnNo: string, btnName: string }[] }[] = [];
        for (const i of buttons) {
            let flag = false;
            for (const j of result) {
                if (i.menuNo === j.menuNo) {
                    j.buttons.push({btnNo: i.btnNo, btnName: i.btnName});
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                result.push({menuNo: i.menuNo, menuName: i.menuName, buttons: [{btnNo: i.btnNo, btnName: i.btnName}]});
            }
        }
        return result;
    }

    /**
     * 显示按钮分配modal
     * @param event
     */
    clickMenu(event) {
        // 判断点击对象是否是菜单
        if (!event.target.innerText) {
            return;
        }
        const menuName = event.target.innerText;
        // 若菜单未勾选，不展示按钮列表
        const flag = [];
        this.checkMenu(this.nodes, menuName, flag);
        if (!flag.includes(true)) {
            return;
        }
        // 遍历有按钮的菜单
        for (const menu of this.btnMenu) {
            if (menu.menuName === menuName) {
                // 设置要显示的按钮
                for (const button of menu.buttons) {
                    if (this._selectedButton.includes(button.btnNo)) {
                        this._buttons.push({label: button.btnName, value: button.btnNo, checked: true});
                    } else {
                        this._buttons.push({label: button.btnName, value: button.btnNo});
                    }
                }
                break;
            }
        }
        if (this._buttons.length === 0) {
            return;
        }
        this.showButtons = true;
    }

    /**
     * 检查菜单是否被选中
     * @param nodes 所有菜单
     * @param node 需要校验的菜单
     * @param flag 是否被选中
     */
    private checkMenu(nodes, node, flag) {
        for (const x of nodes) {
            if (x.children) {
                this.checkMenu(x.children, node, flag);
            } else {
                if (x.text === node && x.checked) {
                    flag.push(true);
                }
            }
        }
    }

    /**
     * 隐藏按钮分配modal
     */
    hideButtons() {
        this.showButtons = false;
        this._buttons = [];
    }

    /**
     * 保存按钮选择结果
     */
    submitButtons() {
        this._buttons.forEach(button => {
            if (button.checked) {
                if (!this._selectedButton.includes(button.value)) {
                    this._selectedButton.push(button.value);
                }
            } else {
                if (this._selectedButton.includes(button.value)) {
                    this._selectedButton.splice(this._selectedButton.indexOf(button.value), 1);
                }
            }
        });
        this.hideButtons();
    }

}

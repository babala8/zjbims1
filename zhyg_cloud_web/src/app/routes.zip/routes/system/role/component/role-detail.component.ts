import {Component, OnInit, ViewChild} from '@angular/core';
import {RoleService} from '../role.service';
import {ITreeOptions, ITreeState, TreeComponent} from 'angular-tree-component';
import {ORGGRADES} from '../../../../core/constant';
import {environment} from '@env/environment';
import {HttpClient} from '@angular/common/http';
import {_HttpClient} from '@zjft/theme';
import {SysMenuService} from '../../menu/menu.service';
import {NzModalSubject} from 'ng-zorro-antd';

@Component({
    templateUrl: './role-detail.html'
})
export class RoleDetailComponent implements OnInit {
    _isSpinning = true;
    role;
    nodes;
    formModel = {};

    treeState;
    selectedNodes;
    grades = ORGGRADES;
    selected = true;
    @ViewChild(TreeComponent) tree: TreeComponent;
    options: ITreeOptions = {
        displayField: 'text',
        animateExpand: true,
        animateAcceleration: 6,
        nodeHeight: 15,
        useCheckbox: true,
    };

    constructor(private roleService: RoleService,
                private nzModal: NzModalSubject,
                private service: SysMenuService,
                private httpClient: _HttpClient) {

    }

    ngOnInit() {

        this.service.getMenus()
            .subscribe(data => {
            this.nodes = data[0].children;
            // 获取当前角色关联的菜单，设置菜单树的初始状态
            this.roleService.qryMenuByRoleid(this.role.no)
                .subscribe(data => {
                    this.treeState = {
                        expandedNodeIds: {},
                        activeNodeIds: {},
                        selectedLeafNodeIds: {}
                    };
                    this._isSpinning = false;

                    const array1 = [];  // 已选择的ids
                    if (data.SysRoleMune.buttons) {
                        data.retList = data.SysRoleMune.menus.map(value => {
                            return value.no;
                        });

                        const loop = (array) => {
                            array.forEach(value => {
                                if (data.retList.includes(value.id)) {
                                    value.checked = true;
                                    array1.push(value.id);
                                }
                                if ($.isArray(value.children)) {
                                    loop(value.children);
                                }
                            });
                        };
                        loop(this.nodes);
                    }
                    console.log(this.nodes);

                    this._isSpinning = false;
                    this.formModel['orgType'] = this.role.orgTypeName;
                    this.formModel['name'] = this.role.name;
                    this.formModel['note'] = this.role.note;
                });
        });
    }

    cancel() {
        this.nzModal.destroy('onCancel');
    }

}

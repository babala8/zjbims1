import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '@env/environment';
import {Location} from '@angular/common';

@Injectable()
export class DevService {

    private devsUrl = `${environment.SERVER_URL}` + '/shepherd/system';
    /**
     * 离行在行标志
     */
    awayFlagInfo = [
        {no: '1', name: '在行'},
        {no: '2', name: '离行'}
    ];
    /**
     * 经营方式
     */
    workTypeInfo = [
        {no: '1', name: '自营'},
        {no: '2', name: '联营'}
    ];
    /**
     * 设备维护商
     */
    devServiceInfo = [
        {no: '1', name: '紫金'}
    ];
    /**
     * 厂商sp类型
     */
    spInfo = [
        {no: '1', name: 'SP'}
    ];
    /**
     * 有线无线标志
     */
    netTypeInfo = [
        {no: '1', name: '有线'},
        {no: '2', name: '无线'}
    ];
    /**
     * 安装方式
     */
    setupTypeInfo = [
        {no: '1', name: '大堂'},
        {no: '2', name: '穿墙'}
    ];

    constructor(private http: HttpClient,
                private location: Location) {
    }

    getDevs(params): Observable<any> {
        return this.http.post<any>(this.devsUrl + '/dev/qryDev', params);
    }


    getDev(devNo): Observable<any> {
        return this.http.post<any>(this.devsUrl + '/dev/qryDevById', {
            devNo: devNo
        });
    }

    addDev(params): Observable<any> {
        return this.http.post<any>(this.devsUrl + '/dev/addDev', params);
    }

    modDev(params): Observable<any> {
        return this.http.post<any>(this.devsUrl + '/dev/modDev', params);
    }

    delDev(params): Observable<any> {
        return this.http.post<any>(this.devsUrl + '/dev/delDev', params);
    }

    /**
     * 查询所有设备分类
     */
    getDevCatalogInfo(params): Observable<any> {
        return this.http.post<any>(this.devsUrl + '/catalog/qryCatalog', params);
    }

    /**
     * 查询所有设备型号
     */
    getDevTypeByVendor(params): Observable<any> {
        return this.http.post<any>(this.devsUrl + '/type/qryType', params);
    }

    /**
     * 查询所有设备品牌
     */
    getDevVendorInfo(params): Observable<any> {
        return this.http.post<any>(this.devsUrl + '/vendor/qryVendor', params);
    }

    getAwayFlagInfo() {
        return this.awayFlagInfo;
    }
    getWorkTypeInfo() {
        return this.workTypeInfo;
    }
    getDevServiceInfo() {
        return this.devServiceInfo;
    }
    getSpInfo() {
        return this.spInfo;
    }
    getNetTypeInfo() {
        return this.netTypeInfo;
    }
    getSetupTypeInfo() {
        return this.setupTypeInfo;
    }

    back() {
        this.location.back();
    }

}

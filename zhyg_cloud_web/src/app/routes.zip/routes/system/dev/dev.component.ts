import {Component, OnInit, TemplateRef, OnChanges} from '@angular/core';
import {DevService} from './dev.service';
import {OrgService} from '../org/org.service';
import {NzMessageService, NzModalService} from 'ng-zorro-antd';
import {Page} from '../../../models/page';
import {HttpResponse} from '@angular/common/http';
import {Dev} from '../../../models/dev';
import {Org} from '../../../models/org';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {SessionService} from '@core/session.service';
import {DevDetailComponent} from '../dev/component/dev-detail.component';
import {DevModifyComponent} from '../dev/component/dev-modify.component';
import {DevAddComponent} from '../dev/component/dev-add.component';
import {SysMenuService} from '../menu/menu.service';

@Component({
    templateUrl: './dev.html',
})
export class DevComponent implements OnInit, OnChanges {

    validateForm: FormGroup;
    dataSet = [];
    devTypeList = [];
    devCatalogList = [];
    devVendorList = [];
    orgNoList = [];
    loading = true;
    dev: Dev;
    org: Org;
    page = new Page();

    constructor(
                private fb: FormBuilder,
                private devService: DevService,
                private orgService: OrgService,
                private modal: NzModalService,
                private session: SessionService,
                private menuService: SysMenuService,
                private message: NzMessageService,
    ) {
    }

    ngOnInit() {
        this.validateForm = this.fb.group({
            devNo: [null, Validators.maxLength(20)],
            ip: [null, Validators.maxLength(20)],
            org: [
                {no: '', name: ''}],
            devCatalog: [null, Validators.maxLength(5)],
            devVendor: [null, Validators.maxLength(5)],
            devType: [null, Validators.maxLength(5)],
        });
        this.devService.getDevCatalogInfo({}).subscribe(
            data => {
                this.devCatalogList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.devService.getDevVendorInfo({}).subscribe(
            data => {
                this.devVendorList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.refreshData(true);
    }
    ngOnChanges() {

    }

    refreshData(reset = false) {
        if (reset) {
            this.page.curPage = 1;
        }
        this.loading = true;
        const params = {
            devNo: this.validateForm.controls.devNo.value || '',
            ip: this.validateForm.controls.ip.value || '',
            orgNo: this.validateForm.controls.org.value.no || '',
            devCatalog: this.validateForm.controls.devCatalog.value || '',
            devVendor: this.validateForm.controls.devVendor.value || '',
            devType: this.validateForm.controls.devType.value || '',
            curPage: this.page.curPage,
            pageSize: this.page.pageSize,
        };
        console.log(params);
        // 获取当前页
        this.devService.getDevs(params)
            .subscribe(data => {
                data.retList.forEach(data1 => {
                    if (data1.awayFlag === '1') {
                        data1.awayFlag = '在行';
                    }else {
                        data1.awayFlag = '离行';
                    }
                });
                this.dataSet = data.retList;
                this.page.totalRow = data['totalRow'];
                this.loading = false;
            }, (error) => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    showDetail(devs) {
        const modal = this.modal.open({
            title: '设备详情',
            content: DevDetailComponent,
            width: '60%',
            componentParams: {
                devs: devs
            },
            onOk: () => {
            },
            onCancel: () => {
            },
            footer: false
        });
    }

    modDev(devs) {
        const modal = this.modal.open({
            title: '修改设备',
            content: DevModifyComponent,
            width: '60%',
            componentParams: {
                devs: devs
            },
            onOk: () => {
            },
            onCancel: () => {
            },
            footer: false
        });
    }

    addDev() {
        const modal = this.modal.open({
            title: '添加设备',
            content: DevAddComponent,
            width: '60%',
            componentParams: {
            },
            onOk: () => {
            },
            onCancel: () => {
            },
            footer: false
        });
    }

    search() {
        this.refreshData(true);
    }

    confirmDel(devNo) {
        this.devService.delDev({
            no: devNo
        }).subscribe(data => {
            this.refreshData(false);
            this.message.success('删除设备成功');
            this.refreshData(false);
        }, (error) => {
            console.log(error);
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    /**
     * 选择设备品牌后，查询用户可选的设备类型
     * @param evt
     */
    selectDevType(evt: any) {
        console.log(evt);
        if (evt) {
            const params = {
                devVendor: evt || '',
                devCatalog: '',
            }
            console.log(params);
            this.devService.getDevTypeByVendor(params).subscribe(
                data => {
                    this.devTypeList = data.retList;
                    console.log(this.devTypeList);
                }, error => {
                    console.log(error);
                    if (error instanceof HttpResponse) {
                        this.message.error(error.body.retMsg);
                    }
                }
            );
        }
    }

    /**
     * 重置查询条件
     *
     */
    reset() {
        this.validateForm.reset();
        this.validateForm.controls.devNo.setValue('');
        this.validateForm.controls.ip.setValue('');
        this.validateForm.controls.org.setValue({});
        this.validateForm.controls.devCatalog.setValue('');
        this.validateForm.controls.devVendor.setValue('');
        this.validateForm.controls.devType.setValue('');
        this.devTypeList = [];
        this.refreshData(true);
    }

    cancel() {

    }

    /**
     * 校验按钮权限
     * @param menuName
     * @param btnName
     */
    checkBtn(menuName: string, btnName: string): boolean {
        return this.menuService.checkBtn(menuName, btnName);
    }

}

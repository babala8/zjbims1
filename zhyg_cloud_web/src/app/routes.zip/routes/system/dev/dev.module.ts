import {NgModule} from '@angular/core';
import {SharedModule} from '../../../shared/shared.module';
import {DevComponent} from './dev.component';
import {DevService} from './dev.service';
import {SystemRoutingModule} from '../system.routing';
import {DevAddComponent} from './component/dev-add.component';
import {DevModifyComponent} from './component/dev-modify.component';
import {DevDetailComponent} from './component/dev-detail.component';

@NgModule({
    imports: [
        SharedModule,
        SystemRoutingModule,
    ],
    declarations: [
        DevComponent,
        DevAddComponent,
        DevModifyComponent,
        DevDetailComponent

    ],
    entryComponents: [
        DevAddComponent,
        DevModifyComponent,
        DevDetailComponent

    ],
    providers: [
        DevService
    ]
})
export class DevModule {

}

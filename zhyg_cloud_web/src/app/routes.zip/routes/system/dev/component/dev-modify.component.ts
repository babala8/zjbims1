import {Component, OnInit} from '@angular/core';
import {DevService} from '../dev.service';
import {OrgService} from '../../org/org.service';
import {Dev} from '../../../../models/dev';
import {Org} from '../../../../models/org';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {HttpResponse} from '@angular/common/http';
import {SessionService} from '@core/session.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
    templateUrl: './dev-modify.html'
})
export class DevModifyComponent implements OnInit {

    validateForm: FormGroup;
    devTypeList = [];
    devCatalogList = [];
    devVendorList = [];
    orgNoList = [];
    awayFlagList = [];
    workTypeList = [];
    devServiceList = [];
    spList = [];
    netTypeList = [];
    setupTypeList = [];
    dev: Dev;
    devs;
    org = new Org();
    loading = false;
    syn_startDate = null;
    syn_stopDate = null;
    syn_expireDate = null;
    syn_patrolPeriod = null;

    constructor(private fb: FormBuilder,
                private devService: DevService,
                private orgService: OrgService,
                private nzModal: NzModalSubject,
                private session: SessionService,
                private message: NzMessageService,
                private route: ActivatedRoute,
                private router: Router) {

    }

    /**
     * 选择设备品牌后，查询用户可选的设备类型
     * @param evt
     */
    selectDevType(evt: any) {
        console.log(evt);
        if (evt) {
            const params = {
                devVendor: evt || '',
                devCatalog: '',
            }
            console.log(params);
            this.devService.getDevTypeByVendor(params).subscribe(
                data => {
                    this.devTypeList = data.retList;
                    console.log(this.devTypeList);
                }, error => {
                    console.log(error);
                    if (error instanceof HttpResponse) {
                        this.message.error(error.body.retMsg);
                    }
                }
            );
        }
    }


    ngOnInit(): void {
        // 初始化表单
        //const devNo = this.route.snapshot.paramMap.get('devNo');
        const devNo = this.devs.devNo;
        console.log('devNo:' + devNo);
        this.devService.getDevTypeByVendor({}).subscribe(
            data => {
                this.devTypeList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.devService.getDevCatalogInfo({}).subscribe(
            data => {
                this.devCatalogList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.devService.getDevVendorInfo({}).subscribe(
            data => {
                this.devVendorList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.awayFlagList = this.devService.getAwayFlagInfo();
        this.workTypeList = this.devService.getWorkTypeInfo();
        this.devServiceList = this.devService.getDevServiceInfo();
        this.spList = this.devService.getSpInfo();
        this.netTypeList = this.devService.getNetTypeInfo();
        this.setupTypeList = this.devService.getSetupTypeInfo();
        this.validateForm = this.fb.group({
            devNo: [null, [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
            ip: [null, [Validators.required, Validators.maxLength(20)]],
            upper: [null, [Validators.required, Validators.maxLength(20)]],
            devType: [null, [Validators.required, Validators.maxLength(5)]],
            devCatalog: [null, [Validators.required, Validators.maxLength(5)]],
            devVendor: [null, [Validators.required, Validators.maxLength(5)]],
            address: [null, [Validators.required, Validators.maxLength(80)]],
            awayFlag: [null, [Validators.required]],
            workType: [null, [Validators.required]],
            devService: [null, [Validators.required]],
            sp: [null, [Validators.required]],
            virtualTellerNo: [null, [Validators.required, Validators.maxLength(10)]],
            setupType: [null, [Validators.required]],
            x: [null],
            y: [null],
            serial: [null, Validators.maxLength(40)],
            cashboxLimit: [null, Validators.maxLength(50)],
            netType: [null],
            commPacket: [null, Validators.maxLength(20)],
            syn_startDate: [null],
            syn_stopDate: [null],
            syn_expireDate: [null],
            syn_patrolPeriod: [null],
        });

        // 获取设备详细信息
        this.loading = true;
        this.devService.getDev(devNo).subscribe(
            data => {
                this.loading = false;
                console.log(data);
                this.dev = data;
                this.validateForm.controls.devNo.setValue(this.dev.devNo);
                this.validateForm.controls.ip.setValue(this.dev.ip);
                this.validateForm.controls.devCatalog.setValue(this.dev.devCatalog);
                this.validateForm.controls.devVendor.setValue(this.dev.devVendor);
                this.validateForm.controls.upper.setValue({
                    no: this.dev.orgNo,
                    name: this.dev.orgName
                } || {});
                this.validateForm.controls.devType.setValue(this.dev.devType);
                this.validateForm.controls.address.setValue(this.dev.address || '');
                this.validateForm.controls.x.setValue(this.dev.x || '');
                this.validateForm.controls.y.setValue(this.dev.y || '');
                this.validateForm.controls.awayFlag.setValue(this.dev.awayFlag || '');
                this.validateForm.controls.workType.setValue(this.dev.workType || '');
                this.validateForm.controls.devService.setValue(this.dev.devService || '');
                this.validateForm.controls.sp.setValue(this.dev.sp || '');
                this.validateForm.controls.virtualTellerNo.setValue(this.dev.virtualTellerNo);
                this.validateForm.controls.serial.setValue(this.dev.serial);
                this.validateForm.controls.syn_startDate.setValue(this.string2Date(this.dev.startDate));
                this.validateForm.controls.syn_stopDate.setValue(this.string2Date(this.dev.stopDate));
                this.validateForm.controls.syn_expireDate.setValue(this.string2Date(this.dev.expireDate));
                this.validateForm.controls.syn_patrolPeriod.setValue(this.string2Date(this.dev.patrolPeriod));
                this.validateForm.controls.cashboxLimit.setValue(this.dev.cashboxLimit || '');
                this.validateForm.controls.netType.setValue(this.dev.netType || '');
                this.validateForm.controls.commPacket.setValue(this.dev.commPacket || '');
                this.validateForm.controls.setupType.setValue(this.dev.setupType || '');
            },
            error => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    _submitForm() {
        for (const i in this.validateForm.controls) {
            if (this.validateForm.controls[i]) {
                this.validateForm.controls[i].markAsDirty();
            }
        }

        if (this.validateForm.invalid) {
            return;
        }
        const params = {
            no: this.validateForm.controls.devNo.value,
            ip: this.validateForm.controls.ip.value,
            orgNo: this.validateForm.controls.upper.value.no ,
            devCatalog: this.validateForm.controls.devCatalog.value ,
            devVendor: this.validateForm.controls.devVendor.value ,
            devType: this.validateForm.controls.devType.value ,
            address: this.validateForm.controls.address.value || '',
            x: this.validateForm.controls.x.value || '',
            y: this.validateForm.controls.y.value || '',
            awayFlag: this.validateForm.controls.awayFlag.value || '',
            workType: this.validateForm.controls.workType.value || '',
            devService: this.validateForm.controls.devService.value || '',
            sp: this.validateForm.controls.sp.value || '',
            virtualTellerNo: this.validateForm.controls.virtualTellerNo.value,
            serial: this.validateForm.controls.serial.value,
            startDate: this.date2String(this.validateForm.controls.syn_startDate.value) ,
            stopDate: this.date2String(this.validateForm.controls.syn_stopDate.value) ,
            expireDate: this.date2String(this.validateForm.controls.syn_expireDate.value),
            patrolPeriod: this.date2String(this.validateForm.controls.syn_patrolPeriod.value),
            cashboxLimit: this.validateForm.controls.cashboxLimit.value || '',
            netType: this.validateForm.controls.netType.value || '',
            commPacket: this.validateForm.controls.commPacket.value || '',
            setupType: this.validateForm.controls.setupType.value || '',
        };
        this.loading = true;
        this.devService.modDev(params)
            .subscribe(data => {
                this.loading = false;
                this.message.success('修改设备成功！');
                this.nzModal.destroy('onOk');
                this.router.navigate(['/system/dev']);
            }, (error) => {
                this.loading = false;
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    getFormControl(name) {
        return this.validateForm.controls[name];
    }

    updateConfirmValidator() {
        setTimeout(() => {
            this.validateForm.controls['name'].updateValueAndValidity();
        });
    }

    /**
     * 日期和字符串相互转换
     * @param date
     */
    date2String(date: Date): string {
        if (!date) {
            date = new Date();
        }
        const _date = date.toISOString().substring(0, 10);
        return _date;
    }

    string2Date(str: string): Date {
        return new Date(str.replace(/-/g, '/'));
    }

    cancel() {
        this.nzModal.destroy('onCancel');
    }

}

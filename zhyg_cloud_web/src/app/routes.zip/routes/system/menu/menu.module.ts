import {NgModule} from '@angular/core';
import {SharedModule} from '@shared/shared.module';
import {MenuDefineComponent} from './define/menu-define.component';
import {NgJsonEditorModule} from 'ang-jsoneditor';

@NgModule({
    imports: [
        SharedModule,
        NgJsonEditorModule,
    ],
    declarations: [
        MenuDefineComponent,
    ],
    entryComponents: [
        MenuDefineComponent
    ]
})
export class MenuModule {

}

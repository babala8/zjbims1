import {Component, OnInit, TemplateRef} from '@angular/core';
import {UserService} from './user.service';
import {User} from '../../../models/user';
import {UserAddComponent} from './component/user-add.component';
import {UserDetailComponent} from './component/user-detail.component';
import {UserModifyComponent} from './component/user-modify.component';
import {NzMessageService, NzModalService} from 'ng-zorro-antd';
import {Page} from '../../../models/page';
import {RoleService} from '../role/role.service';
import {SessionService} from '../../../core/session.service';
import {OrgService} from '../org/org.service';
import {HttpResponse} from '@angular/common/http';
import * as _ from 'lodash';
import {Md5} from 'ts-md5';
import {SysMenuService} from '../menu/menu.service';

@Component({
    templateUrl: './user.html'
})
export class UserComponent implements OnInit {
    dataSet = [];
    formModel = {};
    page = new Page();
    loading = false;
    nodes = [];
    roles = [];
    org: any;
    curOrg = {
        no: this.session.getUserSession().orgNo,
        name: this.session.getUserSession().orgName,
        //orgType: this.session.getUserSession().org.orgTypeInfo.no
    };

    constructor(private userService: UserService,
                private message: NzMessageService,
                private orgService: OrgService,
                private roleService: RoleService,
                private session: SessionService,
                private modal: NzModalService,
                private menuService: SysMenuService
                ) {
    }

    refreshData(reset = false) {
        if (reset) {
            this.page.curPage = 1;
        }
        this.loading = true;

        const params = {
            userName: this.formModel['userName'] || null,
            userNo: this.formModel['userNo'] || null,
            orgNo: this.formModel['org'].no,
            roleNo: this.formModel['roleNo'] || null,
            curPage: this.page.curPage,
            curRow: this.page.curRow,
            pageSize: this.page.pageSize,
            totalPage: this.page.totalPage || '',
            totalRow: this.page.totalRow || '',
        };
        this.userService.getUserByPage(params)
            .subscribe(_data => {
                console.log(_data);
                this.dataSet = _data['retList'];
                this.page.totalRow = _data['totalRow'];
                this.page.curRow = _data['curRow'];
                this.page.totalPage = _data['totalPage'];
                this.loading = false;
            }, (error) => {
                this.loading = false;
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    search() {
        this.refreshData(true);
    }

    ngOnInit(): void {
        this.formModel['org'] = {no: this.curOrg.no, name: this.curOrg.name};

        const param = {
            orgNo: this.curOrg.no
        };
        this.roleService.qryAvailableRoleByOrgNo(param).subscribe(data => {
            console.log('角色' + data);
            this.roles = data.retList;
        });

        this.refreshData(true);

    }

    addUser() {
        const modal = this.modal.open({
            title: '添加用户',
            maskClosable: false,
            footer: false,
            content: UserAddComponent,
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

    openDetail(user) {
        const modal = this.modal.open({
            title: '用户详细信息',
            content: UserDetailComponent,
            componentParams: {
                user: user
            },
            onOk: () => {
            },
            onCancel: () => {
            },
            footer: false
        });
    }

    modifyUser(user) {
        const modal = this.modal.open({
            title: '修改用户',
            maskClosable: false,
            footer: false,
            content: UserModifyComponent,
            componentParams: {
                user: user
            },
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

    deleteUser(user) {
        this.userService.deleteUser(user.no).subscribe(r => {
            this.message.success(
                `用户${user.no}删除成功！`
            );
            this.refreshData(true);
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    resetPassword(user: User) {
        console.log('reset password!');
        this.userService.getUser(user.no).subscribe(data => {
            const type = {type: 'reset'};
            const params = _.extend({
                userNo: user.no,
                password: Md5.hashStr('abcd1234').toString(),
            });
            console.log(params);
            this.userService.resetPassword(params).subscribe(r => {
                this.message.success('用户密码已重置成功');
                this.refreshData(true);
            }, (error) => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
        });
    }

    unlock(user: User) {
        this.userService.unlock(user.no).subscribe(r => {
            this.message.success(`用户${user.no}已解锁`);
            this.refreshData(true);
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    /**
     * 校验按钮权限
     * @param menuName
     * @param btnName
     */
    checkBtn(menuName: string, btnName: string): boolean {
        return this.menuService.checkBtn(menuName, btnName);
    }


}

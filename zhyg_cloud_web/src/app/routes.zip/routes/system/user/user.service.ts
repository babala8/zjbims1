import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '@env/environment';
import {Location} from '@angular/common';

const httpOptions = {
    headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable()
export class UserService {

    private url = `${environment.SERVER_URL}` + '/shepherd/system/user';

    constructor(private http: HttpClient,
                private location: Location) {
    }

    getUsers(params): Observable<any> {
        return this.http.post(this.url + '/qryAllUsers', params);
    }

    getUserByPage(params): Observable<any> {
        return this.http.post(this.url + '/qryUsersByPages', params);
    }

    getUser(params): Observable<any> {
        return this.http.post(this.url + '/qryUserById', {
            userNo: params
        });
    }

    addUser(params): Observable<any> {
        return this.http.post(this.url + '/addUser', {
            data: params
        });
    }

    updateUser(params): Observable<any> {
        return this.http.post(this.url + '/modUser', params
        );
    }

    deleteUser(userNo): Observable<any> {
        return this.http.post(this.url + '/delUser', {
            userNo: userNo
        });
    }

    resetPassword(params): Observable<any> {
        return this.http.post(this.url + '/modPasswd', params);
    }

    modPassword(params): Observable<any> {
        return this.http.post(this.url + '/modPasswd', params);
    }

    unlock(userNo): Observable<any> {
        return this.http.post(this.url + '/unlock', {
            no: userNo
        });
    }

    cancel() {
        this.location.back();
    }
}

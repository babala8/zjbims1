import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {UserService} from '../user.service';
import {RoleService} from '../../role/role.service';
import {Org} from '../../../../models/org';
import {OrgGrade} from '../../../../models/org-grade';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {SessionService} from '../../../../core/session.service';
//  import {ZjftValidators} from '@zjft/validation';
import * as _ from 'lodash';
import {OrgService} from '../../org/org.service';
import {User} from '../../../../models/user';
import {HttpResponse} from '@angular/common/http';
import {Md5} from 'ts-md5';

@Component({
    templateUrl: './user-add.html'
})
export class UserAddComponent implements OnInit {
    validateForm: FormGroup;
    nodes;
    roles;
    org = new Org();
    orgGrade = new OrgGrade();
    options = {};
    user = new User();
    loading = false;
    curOrg = this.session.getUserSession().org;

    constructor(private fb: FormBuilder,
                private userService: UserService,
                private orgService: OrgService,
                private roleService: RoleService,
                private session: SessionService,
                private nzModal: NzModalSubject,
                private message: NzMessageService) {
    }

    ngOnInit() {

        this.validateForm = this.fb.group({
            no: [null, [Validators.required, Validators.minLength(4), Validators.maxLength(20)]],
            name: [null, [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
            org: [null, [Validators.required]],
            roleNo: [null, [Validators.required]],
            phone: [null, Validators.maxLength(20)],
            mobile: [null, Validators.maxLength(20)],
            email: [null, Validators.maxLength(40)],
        });
        const param = {
            orgNo: this.session.getUserSession().orgNo
        };
        this.roleService.qryAvailableRoleByOrgNo(param).subscribe(data => {
            console.log('角色' + data);
            this.roles = data.retList;
        });


    }

    getFormControl(name) {
        return this.validateForm.controls[name];
    }

    updateConfirmValidator() {
        setTimeout(() => {
            this.validateForm.controls['name'].updateValueAndValidity();
        });
    }

    selectRole($event) {
        this.orgService.getOrg($event.no).subscribe(data => {
            // console.log('设置角色' + data.retData.orgTypeInfo.no);
            const param = {
                orgType: data.orgType,
            };
            this.roleService.qryRoleByOrgType(param).subscribe(_data => {
                this.validateForm.controls.roleNo.setValue(null);
                this.roles = _data.retList;
            });
        });
    }

    _submitForm() {
        for (const i in this.validateForm.controls) {
            if (this.validateForm.controls[i]) {
                this.validateForm.controls[i].markAsDirty();
            }
        }
        if (this.validateForm.invalid) {
            return;
        }
        console.log(this.validateForm.controls['org']);

        const params = _.extend({
            roles: {no: this.validateForm.controls.roleNo.value},
            status: 1,
            orgNo: this.validateForm.controls['org'].value.no,
            passwordMD5: Md5.hashStr('abcd1234').toString(),
        }, this.validateForm.value);
        this.loading = true;
        console.log('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
        console.log(params);
        this.userService.addUser(params)
            .subscribe(data => {
                this.loading = false;
                this.nzModal.destroy('onOk');
                this.message.success(
                    `增加用户成功！`
                );
            }, (error) => {
                this.loading = false;
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    cancel() {
        this.nzModal.destroy('onCancel');
    }
}


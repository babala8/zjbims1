import {Component, OnInit} from '@angular/core';
import {User} from '../../../../models/user';
import {UserService} from '../user.service';
import {OrgService} from '../../org/org.service';
import {RoleService} from '../../role/role.service';
import {ActivatedRoute} from '@angular/router';
import {NzModalSubject} from 'ng-zorro-antd';

@Component({
    selector: 'user-detail',
    templateUrl: './user-detail.html',
})
export class UserDetailComponent implements OnInit {

    user;
    userret;
    userInfo: User;
    nodes = [];
    roles;
    formModel = {};

    constructor(private userService: UserService,
                private route: ActivatedRoute,
                private nzModal: NzModalSubject,
                private orgService: OrgService,
                private roleService: RoleService) {

    }

    ngOnInit(): void {
        console.log(this.user.no);

        this.userService.getUser(this.user.no).subscribe(data => {
            this.userInfo =  data.SysUserInfo;
            console.log('bbbbbbbbbbbbbbbbbbbbbbbbbb')
            console.log(this.userInfo);
            this.formModel['no'] = this.userInfo.no;
            this.formModel['name'] = this.userInfo.name;
            this.formModel['org'] = this.user.orgName,
            this.formModel['roleNo'] = this.user.roleName;
            this.formModel['phone'] = this.userInfo.phone;
            this.formModel['mobile'] = this.userInfo.mobile;
            this.formModel['email'] = this.userInfo.email;

        });
    }

    cancel() {
        this.nzModal.destroy('onCancel');
    }


}


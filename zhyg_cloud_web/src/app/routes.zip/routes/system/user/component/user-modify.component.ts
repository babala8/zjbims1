import {Component, OnInit} from '@angular/core';
import {UserService} from '../user.service';
import {User} from '../../../../models/user';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {OrgService} from '../../org/org.service';
import {RoleService} from '../../role/role.service';
import {Org} from '../../../../models/org';
import {OrgGrade} from '../../../../models/org-grade';
import {HttpResponse} from '@angular/common/http';

@Component({
    templateUrl: './user-modify.html'
})
export class UserModifyComponent implements OnInit {
    validateForm: FormGroup;
    user;
    userret;
    nodes;
    roles;
    org = new Org();
    orgGrade = new OrgGrade();
    options = {};
    loading = false;

    constructor(private fb: FormBuilder,
                private userService: UserService,
                private roleService: RoleService,
                private orgService: OrgService,
                private nzModal: NzModalSubject,
                private message: NzMessageService) {
    }

    ngOnInit() {
        this.validateForm = this.fb.group({
            no: [null, [Validators.required, Validators.minLength(4), Validators.maxLength(20)]],
            name: [null, [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
            org: [null, [Validators.required]],
            roleNo: [null, [Validators.required]],
            phone: [null, Validators.maxLength(20)],
            mobile: [null, Validators.maxLength(20)],
            email: [null, Validators.maxLength(40)],
        });
        const param = {
            orgNo: this.user.orgNo
        };
        this.roleService.qryAvailableRoleByOrgNo(param).subscribe(data => {
            console.log('角色' + data);
            this.roles = data.retList;
        });
        this.userService.getUser(this.user.no).subscribe(result => {
            this.userret = result.SysUserInfo;
            this.validateForm.controls.no.setValue(this.userret.no);
            this.validateForm.controls.name.setValue(this.userret.name);
            this.validateForm.controls.roleNo.setValue(this.user.roleNo);
            this.validateForm.controls.phone.setValue(this.userret.phone);
            this.validateForm.controls.mobile.setValue(this.userret.mobile);
            this.validateForm.controls.email.setValue(this.userret.email);
            this.validateForm.controls.org.setValue({
                    no: this.user.orgNo,
                    name: this.user.orgName
                } || {});
        });
    }


    getFormControl(name) {
        return this.validateForm.controls[name];
    }

    updateConfirmValidator() {
        setTimeout(() => {
            this.validateForm.controls['name'].updateValueAndValidity();
        });
    }

    selectRole($event) {

            this.orgService.getOrg($event.no).subscribe(data => {
                // console.log('设置角色' + data.retData.orgTypeInfo.no);
                const param = {
                    orgType: data.orgType,
                };
                this.roleService.qryRoleByOrgType(param).subscribe(_data => {
                    this.validateForm.controls.roleNo.setValue(null);
                    this.roles = _data.retList;
                    this.validateForm.controls.roleNo.setValue(this.user.roleNo);
                });
            });

    }

    _submitForm() {

        for (const i in this.validateForm.controls) {
            if (this.validateForm.controls[i]) {
                this.validateForm.controls[i].markAsDirty();
            }
        }

        if (this.validateForm.invalid) {
            return;
        }
        const params = {
            userNo: this.validateForm.controls.no.value,
            name: this.validateForm.controls.name.value,
            roleNo: this.validateForm.controls.roleNo.value,
            orgNo: this.validateForm.controls.org.value.no,
            phone: this.validateForm.controls.phone.value,
            mobile: this.validateForm.controls.mobile.value,
            email: this.validateForm.controls.email.value,

        };
        this.loading = true;
        console.log('cccccccccccccccccccccccccc');
        console.log(params);
        this.userService.updateUser(params)
            .subscribe(_data => {
                console.log(_data);
                this.loading = false;
                this.nzModal.destroy('onOk');
                this.message.success(
                    `修改用户成功！`
                );
            }, (error) => {
                this.loading = false;
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });

    }

    cancel() {
        this.nzModal.destroy('onCancel');
    }

}

import {NgModule} from '@angular/core';
import {SystemRoutingModule} from './system.routing';
import {MenuModule} from './menu/menu.module';
import {SysMenuService} from './menu/menu.service';
import {RoleModule} from './role/role.module';
import {OrgModule} from './org/org.module';
import {DevModule} from './dev/dev.module';
import {UserModule} from './user/user.module';

@NgModule({
    imports: [
        MenuModule,
        RoleModule,
        OrgModule,
        DevModule,
        UserModule,
        SystemRoutingModule
    ],
    providers: [
        SysMenuService
    ]
})
export class SystemModule {
    constructor() {
    }
}

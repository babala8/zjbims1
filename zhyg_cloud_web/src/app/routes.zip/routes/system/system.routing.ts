import {Routes, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';
import {MenuDefineComponent} from './menu/define/menu-define.component';
import {RoleComponent} from './role/role.component';
import {RoleAddComponent} from './role/component/role-add.component';
import {RoleModifyComponent} from './role/component/role-modify.component';
import {RoleDetailComponent} from './role/component/role-detail.component';
import {OrgComponent} from './org/org.component';
import {OrgAddComponent} from './org/component/org-add.component';
import {OrgModifyComponent} from './org/component/org-modify.component';
import {DevComponent} from './dev/dev.component';
import {DevAddComponent} from './dev/component/dev-add.component';
import {DevModifyComponent} from './dev/component/dev-modify.component';
import {DevDetailComponent} from './dev/component/dev-detail.component';
import {OrgDetailComponent} from './org/component/org-detail.component';
import {UserComponent} from './user/user.component';
import {UserAddComponent} from './user/component/user-add.component';

const routes: Routes = [
    {
        path: 'menuDefine',
        component: MenuDefineComponent,
        data: {text: '菜单定义'}
    },
    {
        path: 'role',
        component: RoleComponent,
        data: {text: '角色管理'}
    },
    {
        path: 'org',
        component: OrgComponent,
        data: {text: '机构管理'}
    },
    {
        path: 'dev',
        component: DevComponent,
        data: {text: '设备管理'}
    },
    {
        path: 'user',
        component: UserComponent,
        data: {text: '用户管理'}
    }
];

export const SystemRoutingModule: ModuleWithProviders = RouterModule.forChild(routes);

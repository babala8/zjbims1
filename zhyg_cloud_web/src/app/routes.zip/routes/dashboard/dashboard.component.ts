import {Component, OnInit} from '@angular/core';
import {HeaderMenuComponent} from '../../layout/metro/header/components/menu/menu.component';

@Component({
    selector: 'app-demo-dashboard',
    template: `
       lll
        <!--<zj-screen></zj-screen>-->
        <!--<zj-single-dashboard [pageId]="'meta-analysis'"></zj-single-dashboard>-->
    `,
    styles: [`
        :host {
            height: 750px;
            background-color: rebeccapurple;
        }
    `]
})
export class DemoDashboardComponent {

    // constructor(
    //     private headerComponent: HeaderMenuComponent,
    // ) {
    //
    // }
    //
    //  ngOnInit() {
    //     setTimeout(() => {
    //         this.headerComponent.doShow(0);
    //     }, 3000);
    //  }
}

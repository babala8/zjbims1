import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {SessionService} from '@core/session.service';
import 'rxjs/add/operator/map';

@Injectable()
export class DemoDashboardService {

    constructor(private http: HttpClient,
                private session: SessionService) {
    }

    getScreenDef() {
        return this.http.post('/visible/screen/qryScreenInfo', {})
            .map((val: any) => JSON.parse(val.data.content));
    }

    updateScreenDef(newDef) {
        return this.http.post('/visible/screen/updateScreenInfo', {content: newDef});
    }

    // 获取自定义的图表类型
    getSelfDefCharts() {
        return this.http.post('/visible/chartsManage/chart/qryChartList', {
            chartOrgNo_Query: this.session.getUserSession().orgNo
        }).map(data => {
            console.log(data);
            data['retList'].forEach(val => {
                val.id = val.chartId;
                console.log(val);
                if (val.type === '10') {
                    val.children = JSON.parse(val.optionMsg);
                }
            });
            return data['retList'];
        });
    }

    // 根据id获取图表详细信息
    getOptionAndDataById(id) {
        return this.http.post('/visible/chartsManage/chart/qryServiceDataAndView', {
            chartId: id
        }).map(data => {
            console.log(data);
            return {
                element: data['retData']
            };
        });
    }


}

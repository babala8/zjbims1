import {Component, Inject, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {SessionService} from '@core/session.service';
import {NzMessageService, NzModalService} from 'ng-zorro-antd';
import {DA_SERVICE_TOKEN, ITokenService} from '@zjft/auth';
import {LoginService} from './login.service';
import {HttpResponse} from '@angular/common/http';
import {Md5} from 'ts-md5';
import {HttpClient} from '@angular/common/http';
import {MenuService} from '@zjft/theme';
import {SysMenuService} from '../system/menu/menu.service';


@Component({
    selector: 'login',
    templateUrl: './login.html',
    styleUrls: ['./login.less'],
    providers: [LoginService]
})
export class LoginComponent implements OnInit {
    loading = false;
    loginForm: FormGroup;
    passwordMD5;

    constructor(private router: Router,
                private session: SessionService,
                private loginService: LoginService,
                private fb: FormBuilder,
                private modal: NzModalService,
                private message: NzMessageService,
                private http: HttpClient,
                @Inject(DA_SERVICE_TOKEN) private tokenService: ITokenService,
    ) {
    }

    submitForm() {
        for (const i in this.loginForm.controls) {
            if (this.loginForm.controls[i]) {
                this.loginForm.controls[i].markAsDirty();
            }
        }

        if (this.loginForm.invalid) {
            return;
        }
        this.passwordMD5 = Md5.hashStr(this.loginForm.controls['password'].value).toString();

        this.loading = true;
        const params = {
            userNo: this.loginForm.controls['userNo'].value,
            password: this.passwordMD5,
        };
        console.log(params);
        this.loginService.login(params)
            .subscribe(
                data => {
                    this.loading = false;
                    if (data.btnList) {
                        data.btnList = data.btnList.map(x => x.menuName + x.btnName);
                    }
                    this.session.parseData(data);
                    if (data.onlineFlag === '2') {
                        this.router.navigate(['/password/' + this.loginForm.controls['userNo'].value]);
                    } else {
                        this.router.navigate([this.tokenService.redirect || '/userNo']);
                    }
                },
                error => {
                    this.loading = false;
                    if (error instanceof HttpResponse) {
                        this.message.error(error.body.retMsg);
                    }
                }
            );
    }


    ngOnInit() {
        this.session.logout();
        this.loginForm = this.fb.group({
            userNo: [null, [Validators.required]],
            password: [null, [Validators.required]]
        });
    }

}

import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {HttpResponse} from '@angular/common/http';
import {SessionService} from '@core/session.service';
import {ActivatedRoute, Router} from '@angular/router';
import {AppCatalog} from '../../../../models/appCatalog';
import {BenchmarkService} from '../benchmark.service';
import {Org} from '../../../../models/org';
import {OrgType} from '../../../../models/orgType';
import {Page} from '../../../../models/page';
import {BenchmarkComponent} from '../benchmark.components';

@Component({
    selector: 'benchmark-alloc',
    templateUrl: './benchmark-alloc.html'
})
export class BenchmarkAllocComponent implements OnInit {

    validateRangeForm: FormGroup;
    page = new Page();
    isVisible = false;
    appCatalogs: AppCatalog[];
    showOrHide = () => {
        this.isVisible = !this.isVisible;
    };

    constructor(
        private fb: FormBuilder,
        private benchmarkService: BenchmarkService,
        private benchmarkComponent: BenchmarkComponent,
        private nzModal: NzModalSubject,
        private message: NzMessageService,
        private route: ActivatedRoute,
        private router: Router,
        private session: SessionService
    ) {
    }

    /**
     * 初始化表单
     */
    allDevBrand = [];
    allDevType = [];
    DevType = [];
    allDevCatalog = [];
    devdata = [];
    org = new Org();
    orgTypeList: OrgType[] = [];
    modelDevRangeData = [];
    // 存放修改前的标杆设备范围,后续用于标杆同步
    firstQryFlag = true;
    rawDevRangeData = [];
    lastDevRangeData = [];
    orgs: { no: string, name: string }[] = [];

    ngOnInit() {
        this.validateRangeForm = this.fb.group({
            org: [
                {no: '10001', name: '总行'}, [Validators.required]],
            devType: [null, [Validators.required]],
            devBrand: [null, Validators.required],
            devModel: [null, [Validators.required]],
        });
        this.qryAllDevBrand();
        this.qryAllDevType();
        this.qryAllDevCatalog();
        this.qryOrgs();
        this.qryModelRange();

    }

    _allChecked = false;
    _indeterminate = false;
    _displayData = [];
    _allChecked1 = false;
    _indeterminate1 = false;
    _displayData1 = [];

    _displayDataChange1($event) {
        this._displayData1 = $event;
        this._refreshStatus1();
    }

    _refreshStatus1() {
        const allChecked = this._displayData1.every(value => value.checked === true);
        const allUnChecked = this._displayData1.every(value => !value.checked);
        this._allChecked1 = allChecked;
        this._indeterminate1 = (!allChecked) && (!allUnChecked);
    }

    qryDevs() {
        console.log(this.validateRangeForm.controls.org.value.no);
        const page = new Page();
        const param = {
            orgNo: this.validateRangeForm.controls.org.value.no,
            devCatalog: this.validateRangeForm.controls.devType.value || '',
            devVendor: this.validateRangeForm.controls.devBrand.value || '',
            devType: this.validateRangeForm.controls.devModel.value || '',
            pageSize: page.pageSize,
            curPage: page.curPage
        };

        this.benchmarkService.qryDevInfo(param).subscribe(data => {
            this.devdata = data.retList;
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    showModal = () => {
        this.isflag = true;
        this.qryDevs();
    };

    _displayDataChange($event) {
        this._displayData = $event;
        this._refreshStatus();
    }

    _refreshStatus() {
        const allChecked = this._displayData.every(value => value.checked === true);
        const allUnChecked = this._displayData.every(value => !value.checked);
        this._allChecked = allChecked;
        this._indeterminate = (!allChecked) && (!allUnChecked);
    }

    isflag = false;
    isConfirmLoading = false;
    devCat = '';
    range = '';
    selctDev = [];
    selectGroup = [];
    handleOk = () => {
        this.isConfirmLoading = true;
        this._displayData.forEach(data => {
            if (data.checked === true) {
                this.selctDev.push(data);
                this.devCat += (data.devNo + ',');
            }

        });
        this.devCat = this.devCat.substr(0, this.devCat.length - 1);
        this.range = this.devCat;
        if (this.range.length > 15) {
            this.range = this.range.substr(0, 20) + '...';
        }
        this.devCat = '';
        this.isflag = false;
        this.isConfirmLoading = false;

    };

    handleCancel = () => {
        this.isflag = false;
    };
    reset() {
        this.validateRangeForm.reset();
        this.validateRangeForm.controls.org.setValue({no: '10001', name: '总行'});
        this.validateRangeForm.controls.devType.setValue('');
        this.validateRangeForm.controls.devBrand.setValue('');
        this.validateRangeForm.controls.devModel.setValue('');

    }

    submitForm1() {
        const param = {
            org: this.validateRangeForm.controls.org.value.no || '',  // '所有机构',
            type: this.validateRangeForm.controls.devType.value || '', // '所有设备',
            brand: this.validateRangeForm.controls.devBrand.value || '', // '所有品牌',
            model: this.validateRangeForm.controls.devModel.value || '', // '所有型号',
            range: this.range
        };
        const devlist: string[] = [];
        let orgName: string;
        let typeName: string;
        let brandName: string;
        let modelName: string;
        if (!param.org || param.org === '10001') {
            orgName = '总行';
        } else {
            this.orgs.forEach(data => {
                if (data.no === param.org) {
                    orgName = data.name;
                }
            });
        }
        if (param.type !== '') {
            this.allDevCatalog.forEach(Catalog => {
                if (Catalog.no === param.type) {
                    typeName = Catalog.name;
                }
            });
        } else {
            typeName = '所有设备';
        }
        if (param.brand !== '') {
            this.allDevBrand.forEach(Brand => {
                if (Brand.no === param.brand) {
                    brandName = Brand.name;
                }
            });
        } else {
            brandName = '所有品牌';
        }
        if (param.model !== '') {

            this.allDevType.forEach(Type => {
                if (Type.no === param.model) {
                    modelName = Type.name;
                }
            });
        } else {
            modelName = '所有型号';
        }
        if (this.selctDev.length !== 0) {
            this.selctDev.forEach(data => {
                devlist.push(data.devNo);
            });

            this.selectGroup.push(new AddRange(devlist, param.org, orgName, param.type, typeName, param.brand, brandName, param.model, modelName, param.range));
            this.range = '';
            this._displayData.forEach(data => {
                data.checked = false;
            });
        } else {
            this.selectGroup.push(new AddRange(devlist, param.org, orgName, param.type, typeName, param.brand, brandName, param.model, modelName, param.range));
        }

        this.selctDev = [];
    }

    delSelect(index) {
        for (let i = 0, arr = this.selectGroup; i < arr.length; i++) {
            if (i === index) {
                const temp: AddRange[] = this.selectGroup.slice(i, i + 1);
                const strArr = temp[0].range.split(',');
                this.selectGroup.splice(i, 1);
                for (let j = 0, arr1 = this.selctDev; j < arr1.length; j++) {
                    strArr.forEach(data => {
                        if (data === arr1[j].devNo) {
                            this.selctDev.splice(j, 1);
                        }
                    });
                }
            }
        }
    }

    /**
     * 标杆范围同步
     */
    syn() {

        // const modelNo = this.route.snapshot.paramMap.get('no');
        const modelNo = this.benchmarkComponent.logicId1;
        // console.log(this.rawDevRangeData);
        this.qryModelRange();
        // console.log(this.lastDevRangeData);

        let oldmodelRange = [];
        let laastmodelRange = [];
        this.rawDevRangeData.forEach(rawData => {
            oldmodelRange.push({
                devNo: rawData.dev,
                orgNo: rawData.org,
                devType: rawData.type,
                devVendor: rawData.vendor,
                devCatalog: rawData.catalog
            });
        });
        this.lastDevRangeData.forEach(lastData => {
            laastmodelRange.push({
                devNo: lastData.dev,
                orgNo: lastData.org,
                devType: lastData.type,
                devVendor: lastData.vendor,
                devCatalog: lastData.catalog
            });
        });
        console.log(oldmodelRange);
        console.log(laastmodelRange);


        const params = {
            modelId: modelNo,
            userNo: this.session.getUserSession().account,
            oldRange: oldmodelRange,
            range: laastmodelRange
        };

        this.benchmarkService.synModel(params)
            .subscribe(
                data => {
                    this.message.success(`标杆范围同步成功！`);
                    this.nzModal.destroy('onOk');
                    this.firstQryFlag = true;
                }, error => {
                    this.message.error(error.body.retMsg);
                }
            );
    }

    saveRange() {
        const modelNo = this.benchmarkComponent.logicId1;
        const devList: any[] = [];
        this.selectGroup.forEach(data => {
            let devs = '';
            data.devList.forEach(data2 => {
                devs += data2 + ',';
            });
            devs = devs.substring(0, devs.length - 1);
            devList.push({
                devNo: devs,
                orgNo: data.org,
                devType: data.model,
                devVendor: data.brand,
                devCatalog: data.type

            });
        });
        this.selectGroup = [];
        const params = {
            modelId: modelNo,
            range: devList
        };
        this.benchmarkService.rangeModel(params)
            .subscribe(data => {
                this.message.success(`添加标杆范围成功！`);
                this.nzModal.destroy('onOk');
                this.qryModelRange();
            }, (error) => {
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    /**
     * 取消保存范围
     */
    clearRange() {
        this.showOrHide();
        this.validateRangeForm.reset();
        this.selectGroup = [];
    }

    /**
     * 选择设备品牌后，查询用户可选的设备类型
     * @param evt
     */
    selectDevType(evt: any) {
        console.log(evt);
        if (evt) {
            const params = {
                devVendor: evt || '',
                devCatalog: '',
            }
            console.log(params);
            this.benchmarkService.getDevTypeByVendor(params).subscribe(
                data => {
                    this.DevType = data.retList;
                    console.log(this.DevType);
                }, error => {
                    console.log(error);
                    if (error instanceof HttpResponse) {
                        this.message.error(error.body.retMsg);
                    }
                }
            );
        }
    }

    qryAllDevBrand() {
        const param = {};
        this.benchmarkService.qryAllBrand(param).subscribe(data => {
            this.allDevBrand = data.retList;
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    qryAllDevType() {
        const param = {};
        this.benchmarkService.qryAllType(param).subscribe(data => {
            this.allDevType = data.retList;
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    qryAllDevCatalog() {
        const param = {};
        this.benchmarkService.qryAllCatalog(param).subscribe(data => {
            this.allDevCatalog = data.retList;
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    qryOrgs() {
        this.benchmarkService.getOrgs({
            orgNo: this.session.getUserSession().orgNo
        }).subscribe(
            data => {
                this.orgs = data.retList;
            }
        );
    }

    delIndexRange() {
        const modelNo = this.benchmarkComponent.logicId1;
        const delData = [];
        this.modelDevRangeData.forEach(data => {
            if (data.select) {
                delData.push(data.groupNo);
            }
        });
        const param = {
            modelId: modelNo,
            rangeGroup: delData
        };
        this.benchmarkService.delModelRange(param).subscribe(data => {
            this.message.success(`删除标杆范围成功！`);
            this.nzModal.destroy('onOk');
            this.qryModelRange();

        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });

    }

    selectOrg(evt: any) {
        const orgNo = evt.no;
        if (orgNo) {
            this.benchmarkService.getOrg(orgNo)
                .subscribe(_data => {
                        this.org = _data.retList[0];
                        if (this.org.orgGrade === '6') {
                            this.message.error('所选机构不允许作为上级机构!', {nzDuration: 10000});
                        } else {
                            this.benchmarkService.getOrgTypesByGrade(this.org.orgGrade).subscribe(
                                data => {
                                    this.orgTypeList = data.retList;
                                },
                                error => {
                                    this.message.error(error.body.retMsg);
                                }
                            );
                        }
                    }
                );
        }
    }

    qryModelRange() {
            this.page.curPage = 1;
        this.modelDevRangeData = [];
        const modelNo = this.benchmarkComponent.logicId1;
        const param = {
            modelId: modelNo,
            curPage: this.page.curPage,
            pageSize: this.page.pageSize,
        };
        let existModelRange = [];
        const group = [];
        const modelRange = [];
        this.benchmarkService.qryModelRange(param).subscribe(data => {
            existModelRange = data.retList;
            this.page.totalRow = data['totalRow'];
            if (existModelRange) {
                existModelRange.forEach(data1 => {
                    let flag = true;
                    group.forEach(data2 => {
                        if (data1.group === data2) {
                            flag = false;
                        }
                    });
                    if (flag) {
                        group.push(data1.group);
                    }
                });
            }
            group.forEach(tem => {
                modelRange.push({
                    groupNo: tem,
                    org: '',
                    type: '',
                    vendor: '',
                    catalog: '',
                    dev: []
                });
            });
            if (existModelRange) {
                existModelRange.forEach(e => {
                    modelRange.forEach(f => {
                        if (f.groupNo === e.group) {
                            if (e.field === 'org') {
                                f.org = e.value;
                            }
                            if (e.field === 'type') {
                                f.type = e.value;
                            }
                            if (e.field === 'vendor') {
                                f.vendor = e.value;
                            }
                            if (e.field === 'catalog') {
                                f.catalog = e.value;
                            }
                            if (e.field === 'dev') {
                                f.dev = JSON.parse(e.value);
                            }
                        }
                    });
                });
            }

            modelRange.forEach(h => {
                //   modelDevRangeData = [];
                //  modelDevRangeDisplay = [];
                let orgName: string;
                let typeName: string;
                let vendorNmae: string;
                let catalogName: string;
                if (!h.org || h.org === '10001') {
                    orgName = '总行';
                } else {
                    this.orgs.forEach(data1 => {
                        if (data1.no === h.org) {
                            orgName = data1.name;
                        }
                    });
                }
                if (h.type !== '') {
                    this.allDevCatalog.forEach(Catalog => {
                        if (Catalog.no === h.type) {
                            typeName = Catalog.name;
                        }
                    });
                } else {
                    typeName = '所有设备';
                }
                if (h.vendor !== '') {
                    this.allDevBrand.forEach(vendor => {
                        if (vendor.no === h.vendor) {
                            vendorNmae = vendor.name;
                        }
                    });
                } else {
                    vendorNmae = '所有品牌';
                }
                if (h.catalog !== '') {
                    this.allDevType.forEach(catalog => {
                        if (catalog.no === h.catalog) {
                            catalogName = catalog.name;
                        }
                    });
                } else {
                    catalogName = '所有型号';
                }
                this.modelDevRangeData.push({
                    groupNo: h.groupNo,
                    org: orgName,
                    type: typeName,
                    vendor: vendorNmae,
                    catalog: catalogName,
                    dev: h.dev,
                    select: false
                });
            });
            this.lastDevRangeData = modelRange;
            if (this.firstQryFlag) {
                this.rawDevRangeData = modelRange;
                this.firstQryFlag = false;
            }
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    return() {
        this.benchmarkService.back();
    }

    backModel() {
        this.benchmarkComponent.flag = true;
    }
}

export class AddRange {
    devList: string[] = [];
    org: any;
    orgName: any;
    type: any;
    typeName: any;
    brand: any;
    brandName: any;
    model: any;
    modelName: any;
    range: any;

    constructor(
        devlst: string[],
        org: any,
        orgName: any,
        type: any,
        typeName: any,
        brand: any,
        brandName: any,
        model: any,
        modelName: any,
        range: any
    ) {
        this.devList = devlst;
        this.org = org;
        this.orgName = orgName;
        this.type = type;
        this.typeName = typeName;
        this.brand = brand;
        this.brandName = brandName;
        this.model = model;
        this.modelName = modelName;
        this.range = range;
    }
}

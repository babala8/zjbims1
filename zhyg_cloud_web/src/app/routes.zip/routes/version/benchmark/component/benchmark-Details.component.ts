import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {HttpResponse} from '@angular/common/http';
import {SessionService} from '@core/session.service';
import {ActivatedRoute, Router} from '@angular/router';
import {AppstoreService} from '../../appstore/appstore.service';
import {BenchmarkComponent} from '../benchmark.components';
import {BenchmarkService} from '../benchmark.service';
import {Page} from '../../../../models/page';

@Component({
    selector: 'benchmark-details',
    templateUrl: './benchmark-Details.html'
})
export class BenchmarkDetailsComponent implements OnInit {

    page = new Page();
    modelDevRangeData = [];
    allDevBrand = [];
    allDevType = [];
    allDevCatalog = [];
    orgs: { no: string, name: string }[] = [];
    deployInfo = [];
    modelInfo: {name: string, type: string, desc: string} = {name: '', type: '', desc: ''};

    constructor(
        private fb: FormBuilder,
        private nzModal: NzModalSubject,
        private benchmarkService: BenchmarkService,
        private benchmarkComponent: BenchmarkComponent,
        private message: NzMessageService,
        private route: ActivatedRoute,
        private router: Router,
        private session: SessionService
    ) {
    }

    /**
     * 初始化表单
     */
    ngOnInit() {
        this.qryModelById();
        this.qryAllDevBrand();
        this.qryAllDevType();
        this.qryAllDevCatalog();
        this.qryOrgs();
        this.qryModelRange();
        this.qryDeployVersion();
    }
    qryAllDevBrand() {
        const param = {};
        this.benchmarkService.qryAllBrand(param).subscribe(data => {
            this.allDevBrand = data.retList;
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    qryAllDevType() {
        const param = {};
        this.benchmarkService.qryAllType(param).subscribe(data => {
            this.allDevType = data.retList;
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    qryAllDevCatalog() {
        const param = {};
        this.benchmarkService.qryAllCatalog(param).subscribe(data => {
            this.allDevCatalog = data.retList;
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    qryOrgs() {
        this.benchmarkService.getOrgs({
            orgNo: this.session.getUserSession().orgNo
        }).subscribe(
            data => {
                this.orgs = data.retList;
            }
        );
    }

    qryModelById() {
        //const modelNo = this.route.snapshot.paramMap.get('no');
        const modelNo = this.benchmarkComponent.logicId1;
        const param = {
            modelId: modelNo
        };
        this.benchmarkService.qryModelById(param).subscribe(info => {
            this.modelInfo.name = info.modelName;
            if (info.modelType == '1') {
                this.modelInfo.type = '基础标杆';
            }else {
                this.modelInfo.type = '特色标杆';
            }
            this.modelInfo.desc = info.description;
        });
    }

    qryModelRange() {
        this.page.curPage = 1;
        this.modelDevRangeData = [];
        //const modelNo = this.route.snapshot.paramMap.get('no');
        const modelNo = this.benchmarkComponent.logicId1;
        const param = {
            modelId: modelNo,
            curPage: this.page.curPage,
            pageSize: this.page.pageSize,
        };
        let existModelRange = [];
        const group = [];
        const modelRange = [];
        this.benchmarkService.qryModelRange(param).subscribe(data => {
            existModelRange = data.retList;
            this.page.totalRow = data['totalRow'];
            if(existModelRange) {
                existModelRange.forEach(data1 => {
                    let flag = true;
                    group.forEach(data2 => {
                        if (data1.group === data2) {
                            flag = false;
                        }
                    });
                    if (flag) {
                        group.push(data1.group);
                    }
                });
            }
            group.forEach(tem => {
                modelRange.push({
                    groupNo: tem,
                    org: '',
                    type: '',
                    vendor: '',
                    catalog: '',
                    dev: []
                });
            });
            if(existModelRange) {
                existModelRange.forEach(e => {
                    modelRange.forEach(f => {
                        if (f.groupNo === e.group) {
                            if (e.field === 'org') {
                                f.org = e.value;
                            }
                            if (e.field === 'type') {
                                f.type = e.value;
                            }
                            if (e.field === 'vendor') {
                                f.vendor = e.value;
                            }
                            if (e.field === 'catalog') {
                                f.catalog = e.value;
                            }
                            if (e.field === 'dev') {
                                f.dev = JSON.parse(e.value);
                            }
                        }
                    });
                });
            }

            modelRange.forEach(h => {
                //   modelDevRangeData = [];
                //  modelDevRangeDisplay = [];
                let orgName: string;
                let typeName: string;
                let vendorNmae: string;
                let catalogName: string;
                if (!h.org || h.org === '10001') {
                    orgName = '总行';
                } else {
                    this.orgs.forEach(data1 => {
                        if (data1.no === h.org) {
                            orgName = data1.name;
                        }
                    });
                }
                if (h.type !== '') {
                    this.allDevCatalog.forEach(Catalog => {
                        if (Catalog.no === h.type) {
                            typeName = Catalog.name;
                        }
                    });
                } else {
                    typeName = '所有设备';
                }
                if (h.vendor !== '') {
                    this.allDevBrand.forEach(vendor => {
                        if (vendor.no === h.vendor) {
                            vendorNmae = vendor.name;
                        }
                    });
                } else {
                    vendorNmae = '所有品牌';
                }
                if (h.catalog !== '') {
                    this.allDevType.forEach(catalog => {
                        if (catalog.no === h.catalog) {
                            catalogName = catalog.name;
                        }
                    });
                } else {
                    catalogName = '所有型号';
                }
                this.modelDevRangeData.push({
                    groupNo: h.groupNo,
                    org: orgName,
                    type: typeName,
                    vendor: vendorNmae,
                    catalog: catalogName,
                    dev: h.dev,
                    select: false
                });
            });
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }
    qryDeployVersion() {
        //const modelNo = this.route.snapshot.paramMap.get('no');
        const modelNo = this.benchmarkComponent.logicId1;
        const param = {
            modelId: modelNo
        };
        this.benchmarkService.qryDeployVersion(param)
            .subscribe(data => {
                let temp: string;
                if(data.retList) {
                    data.retList.forEach(data1 => {
                        temp = "" + data1.versionBusNo + "|" + data1.versionNo;
                        this.deployInfo.push({
                            appsId: data1.appsId,
                            appsName: data1.appsName,
                            versionNo: temp
                        });
                    });
                    console.log(this.deployInfo);
                }


            }, (error) => {
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    backModel() {
        //this.benchmarkService.back();
        this.benchmarkComponent.flag = true;
    }


}


import {Component, OnInit} from '@angular/core';
import {NzMessageService, NzModalService} from 'ng-zorro-antd';
import {ActivatedRoute, Router} from '@angular/router';
import {BenchmarkService} from '../benchmark.service';
import {BenchmarkApps} from '../../../../models/benchmarkApps';
import {HttpResponse} from '@angular/common/http';
import {AppVersionMerge} from '../../../../models/appVersionMerge';
import {BenchmarkAppParam} from '../../../../models/benchmarkAppParam';
import {SessionService} from '@core/session.service';
import {BenchmarkComponent} from '../benchmark.components';


@Component({
    selector: 'benchmark-deploy',
    templateUrl: './benchmark-deploy.html',
})
export class BenchmarkDeployComponent implements OnInit {

    formModel;
    loading = true;
    benchmarkNo;
    addVisible = false;
    paramVisible = false;
    appName_qry;
    current = 0;
    /**
     * 应用历史版本信息
     */
    historyVersions: BenchmarkApps[] = [];
    /**
     * 应用历史版本按应用标识合并结果
     */
    mergeHistoryVersions = {};
    /**
     * 已部署应用当前版本信息
     */
    curVersion: BenchmarkApps[] = [];
    /**
     * 此标杆未部署的应用版本信息
     */
    otherAppVersions: AppVersionMerge[] = [];
    /**
     * 已选择的应用
     */
    selectedApps: BenchmarkApps[] = [];
    /**
     * 应用参数列表
     */
    params: BenchmarkAppParam[] = [];
    /**
     * 是否允许修改参数
     */
    modParam = true;
    /**
     * 同步方式和生效方式列表
     */
    updateModes: { no: string, name: string }[] = [];
    synModes: { no: string, name: string }[] = [];
    /**
     * 选择的同步方式和生效方式
     */
    updateMode;
    synMode;
    /**
     * 同步开始和结束的日期和时间
     */
    syn_start_time;
    syn_end_time;
    /**
     * 生效时间
     */
    update_time;

    constructor(
        private message: NzMessageService,
        private modal: NzModalService,
        private router: Router,
        private route: ActivatedRoute,
        private service: BenchmarkService,
        private benchmarkComponent: BenchmarkComponent,
        private session: SessionService,
    ) {
    }

    ngOnInit() {
        this.benchmarkNo = this.benchmarkComponent.logicId1;
        //this.benchmarkNo = this.route.snapshot.paramMap.get('no');
        this.refreshData();
    }

    refreshData() {
        this.mergeHistoryVersions = {};
        this.loading = true;
        this.service.getAppVersions({
            modelId: this.benchmarkNo,
        }).subscribe(
            data => {
                if (data.retList == null) {
                    this.curVersion = [];
                } else {
                    this.curVersion = data.retList;
                    this.curVersion.forEach(x => {
                        if(x.description) {
                            if(x.description.length > 15) {
                                x.description = x.description.substr(0,15) + '...';
                            }
                        }else {
                            x.description = '';
                        }
                        x.versionNo = x.versionBusNo + ' | ' + x.versionNo + ' | ' + x.description;
                    });
                    this.curVersion.sort();
                }
                console.log('当前版本信息' + this.curVersion);
                // 批量查询应用版本信息
                this.service.qryHistoryVersions({appList: this.curVersion}).subscribe(
                    _data => {
                        this.loading = false;
                        this.historyVersions = _data.retList;
                        this.historyVersions.forEach(histVersion => {
                            if(histVersion.description) {
                                if(histVersion.description.length > 15) {
                                    histVersion.description = histVersion.description.substr(0,15) + '...';
                                }
                            }else {
                                histVersion.description = '';
                            }
                            histVersion.versionNo = histVersion.versionBusNo + ' | ' + histVersion.versionNo + ' | ' + histVersion.description;
                        });
                        console.log('历史版本信息' + this.historyVersions);
                        this.mergeVersions();
                    }, error => {
                        this.loading = false;
                        if (error instanceof HttpResponse) {
                            this.message.error(error.body.retMsg);
                        }
                    }
                );
            }, error => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
    }

    /**
     * 将应用历史版本合并入数组中
     */
    mergeVersions() {
        for (const i of this.curVersion) {
            if (!this.mergeHistoryVersions[i.appsId]) {
                this.mergeHistoryVersions[i.appsId] = [];
            }
            for (const j of this.historyVersions) {
                if (j.appsId === i.appsId && j.versionNo !== i.versionNo) {
                    this.mergeHistoryVersions[i.appsId].push(j.versionNo);
                }
            }
        }
    }

    /**
     * 打开添加应用界面
     */
    showAdd() {
        this.addVisible = true;
        this.qryAllAppVersions({});
    }

    /**
     * 去除已部署的应用并合并版本
     * @param allAppVersions
     */
    mergeVersions_add(allAppVersions): AppVersionMerge[] {
        const result: AppVersionMerge[] = [];
        // 已部署的应用名，减少遍历次数
        let deployedId = '';
        for (const i of allAppVersions) {
            if (i.appsId === deployedId) {
                continue;
            }
            // 应用是否已部署
            let deployed = false;
            for (const j of this.curVersion) {
                if (i.appsId === j.appsId) {
                    deployed = true;
                    // 记录已部署的应用名
                    deployedId = j.appsId;
                    break;
                }
            }
            if (deployed) {
                continue;
            }
            // 应用是否存在结果中
            let exist = false;
            for (const k of result) {
                if (k.appsId === i.appsId) {
                    k.versions.push(i.versionNo);
                    exist = true;
                    break;
                }
            }
            if (!exist) {
                result.push(new AppVersionMerge(i.appsId, i.appsName, [i.versionNo], i.versionBusNo));
            }
        }
        return result;
    }

    /**
     * 查询应用信息
     * @param params
     */
    qryAllAppVersions(params) {
        this.loading = true;
        this.service.qryAllAppVersions(params).subscribe(
            data => {
                this.loading = false;
                this.otherAppVersions = this.mergeVersions_add(data.retList);
                let tmpAppVersions: AppVersionMerge[] = [];
                this.otherAppVersions.forEach(x => {
                    let arr = [];
                    for (let i of x.versions) {
                       // i = x.versionBusNo + ' | ' + i;
                        arr.push(x.versionBusNo + ' | ' + i);
                    }
                    x.versions = arr;
                });

                for (const i of this.selectedApps) {
                    for (const j of this.otherAppVersions) {
                        if (i.appsId === j.appsId) {
                            j.selected = true;
                            console.log(i.appsId + i.versionNo);
                            j.selectedVersion = i.versionNo;
                        }
                    }
                }
            }, error => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
    }

    /**
     * 改变应用版本
     * @param appId 应用标识
     * @param versionNo 选择的版本号
     * @param i 应用列表index
     * @param j 版本列表index
     * @param type 区分查询和添加
     */
    changeVersion(appId: string, versionNo: string, i: number, j: number, type: string) {

        if (type === 'qry') {
            if (this.curVersion[i].versionNo === '选择版本') {
                this.mergeHistoryVersions[appId].splice(j, 1);
            } else {
                (this.mergeHistoryVersions[appId])[j] = this.curVersion[i].versionNo;
            }
            this.curVersion[i].versionNo = versionNo;
            this.mergeHistoryVersions[appId].sort();
            this.mergeHistoryVersions[appId].reverse();

        } else {
            if (this.otherAppVersions[i].selectedVersion === '选择版本') {
                this.otherAppVersions[i].versions.splice(j, 1);
            } else {
                this.otherAppVersions[i].versions[j] = this.otherAppVersions[i].selectedVersion;
            }
            this.otherAppVersions[i].selectedVersion = versionNo;
            for (const k of this.selectedApps) {
                if (k.appsId === appId) {
                    k.versionNo = versionNo;
                }
            }
            this.otherAppVersions[i].versions.sort();
            this.otherAppVersions[i].versions.reverse();
        }
    }

    /**
     * 应用添加界面查询应用
     */
    searchApp() {
        this.qryAllAppVersions({appName: this.appName_qry});
    }

    /**
     * 返回全量结果
     */
    showAll() {
        this.qryAllAppVersions({});
        this.appName_qry = '';
    }

    /**
     * 选择应用
     * @param index
     */
    selectApp(index: number) {
        this.otherAppVersions[index].selected = !this.otherAppVersions[index].selected;
        let exist = false;
        for (const i in this.selectedApps) {
            if (this.selectedApps[i].appsId === this.otherAppVersions[index].appsId) {
                this.selectedApps[i].selected = !this.selectedApps[i].selected;
                if (!this.selectedApps[i].selected) {
                    this.selectedApps.splice(Number(i), 1);
                }
                exist = true;
                break;
            }
        }
        if (!exist) {
            console.log(this.otherAppVersions[index].selectedVersion);
            this.selectedApps.push({
                appsId: this.otherAppVersions[index].appsId,
                versionNo: this.otherAppVersions[index].selectedVersion,
                selected: true
            });
        }
    }

    /**
     * 取消添加应用
     */
    cancelAdd() {
        this.addVisible = false;
        this.selectedApps = [];
        this.otherAppVersions = [];
    }

    /**
     * 确认添加应用
     */
    submitAdd() {
        const appList = [];
        for (const i of this.otherAppVersions) {
            if (i.selected) {
                const versionNo: string = (i.selectedVersion.split('|'))[1].trim();
                appList.push({appsId: i.appsId, versionNo: versionNo});
            }
        }
        this.loading = true;
        this.service.addAppVersions({
            modelId: this.benchmarkNo,
            appList: appList
        }).subscribe(
            data => {
                this.message.success(data.retMsg);
                this.cancelAdd();
                this.refreshData();
            }, error => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
    }

    /**
     * 删除应用
     * @param appId
     */
    confirmDel(appId: string) {
        this.loading = true;
        this.service.delAppVersion({modelId: this.benchmarkNo, appsId: appId}).subscribe(
            data => {
                this.loading = false;
                this.message.success(data.retMsg);
                this.refreshData();
            }, error => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
    }

    /**
     * 保存版本&& 设置参数
     * @param appsId
     * @param versionNo
     */
    setParam(appsId: string, versionNo: string) {
        let versionNoArr = versionNo.split('|');
        let versionNo1 = versionNoArr[1].trim();
        // 修改应用版本
        this.service.modAppVersion({appsId: appsId, versionNo: versionNo1, modelId: this.benchmarkNo}).subscribe(
            data => {
            }, error => {
                this.message.error(error.body.retMsg);
            }
        );
        // 查询应用版本参数
        this.loading = true;
        this.service.qryModelAppParam({
            modelId: this.benchmarkNo,
            appsId: appsId,
            version: versionNo1
        }).subscribe(
            data => {
                this.loading = false;
                if (!data.retList) {
                    this.message.warning('该应用版本没有参数设置');
                    return;
                }
                for (const i of data.retList) {
                    // 去除不可设置的参数
                    if (i.showFlag === '0') {
                        continue;
                    }
                    const param: BenchmarkAppParam = i;
                    // 根据valueScope设置输入框类型
                    if (param.valueScope === null || param.valueScope === '') {
                        param.inputType = 'input';
                    } else if (param.valueScope.indexOf('|') > 0) {
                        param.inputType = 'select';
                        if (param.options == null) {
                            param.options = [];
                        }
                        for (const j of param.valueScope.split('|')) {
                            const value = j.split('-')[0];
                            const name = j.split('-')[1];
                            param.options.push({name: name, value: value});
                        }
                   } else if (param.valueScope.indexOf('#') > 0) {
                        param.inputType = 'checkbox';
                        if (param.options == null) {
                            param.options = [];
                        }
                        for (const j of param.valueScope.split('#')) {
                            const value = j.split('-')[0];
                            const name = j.split('-')[1];
                            param.options.push({name: name, value: value, selected: false});
                        }
                    }
                    this.params.push(param);
                }
                this.updateMode = data.updateMode;
                this.synMode = data.synMode;
                if (data.updateMode === '2') {
                    this.update_time = this.string2Date(data.updateTime);
                }
                if (data.synMode === '3') {
                    this.syn_start_time = this.string2Date(data.synStartTime);
                    this.syn_end_time = this.string2Date(data.synEndTime);
                }
                this.synModes = this.service.getSynModes();
                this.updateModes = this.service.getUpdateModes();
                this.paramVisible = true;
            }, error => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
    }

    /**
     * 取消设置参数
     */
    cancelParam() {
        this.modParam = true;
        this.params = [];
        this.paramVisible = false;
        this.syn_start_time = null;
        this.syn_start_time = null;
        this.update_time = null;
        this.updateMode = null;
        this.synMode = null;
    }

    /**
     * 校验同步时间
     */
    startTimeChange() {
        if (this.syn_start_time > this.syn_end_time) {
            this.syn_end_time = '';
        }
    }

    endTimeChange() {
        if (this.syn_start_time > this.syn_end_time) {
            this.syn_start_time = '';
        }
    }

    /**
     * 日期和字符串相互转换
     * @param date
     */
    date2String(date: Date): string {
        if (!date) {
            date = new Date();
        }
        const _date = date.toISOString().substring(0, 10);
        const _time = date.toTimeString().substring(0, 8);
        return _date + ' ' + _time;
    }

    string2Date(str: string): Date {
        return new Date(str.replace(/-/g, '/'));
    }

    /**
     * 保存设置
     */
    submitParam() {
        const paramList: { paramKey: string, paramValue: string }[] = [];
        if (this.modParam) {
            for (const i of this.params) {
                if(i.inputType === 'checkbox') {
                    let temParamValue: string = '';
                    i.options.forEach(j => {
                        if(j.selected) {
                            temParamValue += j.value + '#';
                        }
                    });
                    temParamValue = temParamValue.substr(0,temParamValue.length - 1);
                    paramList.push({paramKey: i.paramKey, paramValue: temParamValue});
                }else {
                    paramList.push({paramKey: i.paramKey, paramValue: i.paramValue});
                }

            }
        }
        const params = {
            modelId: this.benchmarkNo,
            appsId: this.params[0].appsId,
            version: this.params[0].version,
            params: paramList,
            updateMode: this.updateMode,
            synMode: this.synMode,
            updateTime: '',
            synStartTime: '',
            synEndTime: '',
        };
        if (this.synMode === '3') {
            params.synStartTime = this.date2String(this.syn_start_time);
            params.synEndTime = this.date2String(this.syn_end_time);
        }
        if (this.updateMode === '2') {
            params.updateTime = this.date2String(this.update_time);
        }
        this.loading = true;
        this.service.modAppParam(params).subscribe(
            data => {
                this.loading = false;
                this.message.success(data.retMsg);
                this.cancelParam();
            }, error => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
    }

    cancel() {
    }

    backModel() {
        this.benchmarkComponent.flag = true;
    }

    /**
     * 同步标杆
     */
    syn() {
        this.service.synBenchmark({
            modelId: this.benchmarkNo,
            userNo: this.session.getUserSession().account,
            orgNo: this.session.getUserSession().orgNo
        }).subscribe(
            data => {
                this.message.success(data.retMsg);
                this.back();
            }, error => {
                this.message.error(error.body.retMsg);
            }
        );
    }

    /**
     * 返回标杆查询页面
     */
    back() {
        this.router.navigateByUrl('/version/benchmark');
    }

    pre(): void {
        this.current -= 1;
    }

    next(): void {
        this.current += 1;
    }

    done(): void {
        console.log('done');
    }


}

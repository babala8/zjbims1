import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {HttpResponse} from '@angular/common/http';
import {SessionService} from '@core/session.service';
import {ActivatedRoute, Router} from '@angular/router';
import {AppstoreService} from '../../appstore/appstore.service';
import {BenchmarkService} from '../benchmark.service';
import {BenchmarkComponent} from '../benchmark.components';

@Component({
    selector: 'benchmark-modify',
    templateUrl: './benchmark-modify.html'
})
export class BenchmarkModifyComponent implements OnInit {
    validateForm: FormGroup;
    loading = false;
    modelName: string;
    modelDesc: string;
    constructor(
        private fb: FormBuilder,
        private nzModal: NzModalSubject,
        private benchmarkService: BenchmarkService,
        private benchmarkComponent: BenchmarkComponent,
        private message: NzMessageService,
        private route: ActivatedRoute,
        private router: Router,
        private session: SessionService
    ) {
    }

    /**
     * 初始化表单
     */
    ngOnInit() {
        this.validateForm = this.fb.group({
            modelName: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(40)]],
            modelDesc: [null]
        });
        this.qryModelById();
    }

    submitForm() {

        for (const i in this.validateForm.controls) {
            if (this.validateForm.controls[i]) {
                this.validateForm.controls[i].markAsDirty();
            }
        }

        if (this.validateForm.invalid) {
            return;
        }

        //const modelNo = this.route.snapshot.paramMap.get('no');
        const modelNo = this.benchmarkComponent.logicId1;
        const params = {
            modelId: modelNo,
            modelName: this.validateForm.controls.modelName.value,
            description: this.validateForm.controls.modelDesc.value,
        };

        console.log(params);
        this.loading = true;
        this.benchmarkService.modifyModel(params)
            .subscribe(data => {
                this.loading = false;
                this.message.success(`修改标杆成功！`);
                this.nzModal.destroy('onOk');

            }, (error) => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    qryModelById() {
        //const modelNo = this.route.snapshot.paramMap.get('no');
        const modelNo = this.benchmarkComponent.logicId1;
        const params = {
            modelId: modelNo
        };
        this.benchmarkService.qryModelById(params)
            .subscribe(data => {
                this.modelName = data.modelName;
                this.modelDesc = data.description;

            }, (error) => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });

    }

    getFormControl(name) {
        return this.validateForm.controls[name];
    }

    backModel() {
        //this.benchmarkService.back();
        this.benchmarkComponent.flag = true;
    }
}


import {Component, OnInit} from '@angular/core';
import {NzMessageService, NzModalService, NzModalSubject} from 'ng-zorro-antd';
import {ModelInfo} from '../../../models/modelInfo';
import {HttpResponse} from '@angular/common/http';
import {BenchmarkService} from './benchmark.service';
import {animate, state, style, transition, trigger} from '@angular/animations';
import {Router} from '@angular/router';
import {SysMenuService} from '../../system/menu/menu.service';

@Component({
    templateUrl: './benchmark.html',
    styleUrls: ['./benchmark.scss'],
    animations: [
        trigger('showIcon', [
            state('show', style({
                display: 'block',
                opacity: 1,
            })),
            state('hide', style({
                display: 'none',
                opacity: 0,
            })),
            transition('show => hide', animate('200ms ease-out')),
            transition('hide => show', animate('100ms ease-in')),
        ]),
        trigger('high', [
            state('show', style({
                display: 'block',
                opacity: 1,
            })),
            state('hide', style({
                display: 'none',
                opacity: 0,
            })),
            transition('show => hide', animate('200ms ease-out')),
            transition('hide => show', animate('100ms ease-in')),
        ])
    ]
})
export class BenchmarkComponent implements OnInit {
    flag = true;
    logicId1;
    formModel = {};
    dataSet: ModelInfo[] = [];
    options = [];
    // 用于分页显示的相关参数
    curPage = 1;
    totalNum = 0;
    displayDataSet: ModelInfo[] = [];
    // 下面三个参数用来实现点击任意地方保存修改的功能
    // 标杆名称修改完成
    editName = false;
    // 标杆描述修改完成
    editDescription = false;
    // 是否修改过
    hasEdit = false;
    // 当前正在修改的标杆
    editModel: ModelInfo;

    constructor(
        private message: NzMessageService,
        private nzModal: NzModalSubject,
        private modal: NzModalService,
        private router: Router,
        private menuService: SysMenuService,
        private benchmarkService: BenchmarkService,
    ) {
    }

    ngOnInit() {
        this.options = [
            {value: 1, label: '基础标杆'},
            {value: 2, label: '特色标杆'}
        ];
        this.refreshData();
    }

    refreshData() {
        const params = {
            modelName: this.formModel['modelName'] || '',
            modelType: this.formModel['modelType'] || '',
            curPage: 1,
            pageSize: 1000
        };
        console.log('modelName:' + params.modelName + 'modelType:' + params.modelType);

        // 获取标杆列表
        this.benchmarkService.qryModel(params)
            .subscribe(data => {
                if (data.retList) {
                    this.dataSet = data.retList;
                    // 默认不显示删除图标
                    this.dataSet.forEach(x => {
                        x.showDel = 'hide';
                        x.showEdit = false;
                    });
                    this.displayDataSet = this.dataSet;
                    this.totalNum = this.displayDataSet.length;
                    this.changePageIndex();
                } else {
                    this.dataSet = [];
                }
            }, (error) => {
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    search() {
        this.refreshData();
    }

    showModel(logicId) {
        this.flag = false;
        this.logicId1 = logicId;
    }



    delModel(id: string) {
        const params = {
            modelId: id
        };
        this.benchmarkService.delModel(params)
            .subscribe(data => {
                this.message.success(`删除标杆成功！`);
                this.nzModal.destroy('onOk');
                this.refreshData();

            }, (error) => {
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
        this.refreshData();
    }

    /**
     * 鼠标移动到卡片上显示删除图标
     */
    showIcon(i: number) {
        this.dataSet[i].showDel = 'show';
    }

    hideIcon(i: number) {
        this.dataSet[i].showDel = 'hide';
    }

    cancel() {

    }

    /**
     * 失去焦点和获取焦点执行的函数
     */
    blurName() {
        this.editName = false;
        this.hasEdit = true;
    }

    blurDescription() {
        this.editDescription = false;
        this.hasEdit = true;
    }

    focusName() {
        this.editName = true;
        this.hasEdit = true;
    }

    focusDescription() {
        this.editDescription = true;
        this.editName = false;
        this.hasEdit = true;

    }

    /**
     * 显示修改界面
     * @param i
     */
    /**    showEdit(i: number) {
        this.dataSet[i].showEdit = true;
        if (this.editModel) {
            // 只允许同时修改一个标杆
            this.editModel.showEdit = false;
            this.modModel();
            this.editModel = null;
            this.hasEdit = false;
        }
        this.editName = true;
        this.editModel = this.dataSet[i];
    }*/

    hideEdit(event) {
        if (event.target.id === 'editBtn') {
            return;
        }
        if (!(this.editName || this.editDescription) || !this.hasEdit) {
            this.editModel.showEdit = false;
            this.hasEdit = false;
            this.modModel();
            this.editModel = null;
        }
    }

    /**
     * 修改标杆
     */
    modModel() {
        this.benchmarkService.modifyModel({
            modelId: this.editModel.logicId,
            modelName: this.editModel.modelName,
            description: this.editModel.description
        }).subscribe(data => {
            this.message.success(data.retMsg);
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    /**
     * 分页处理
     */
    changePageIndex() {
       // console.log(this.curPage);
        let dataStartIndex = 0;
        let dataEndIndex = 0;
        dataStartIndex = (this.curPage - 1) * 24;
        dataEndIndex = dataStartIndex + 24;
        if(this.dataSet.length < dataEndIndex) {
            dataEndIndex = this.dataSet.length;
        }
        this.displayDataSet = this.dataSet.slice(dataStartIndex, dataEndIndex);
       // console.log(this.displayDataSet);
    }

    jump() {
        this.router.navigate(['/version/benchmark']);
    }

    /**
     * 校验按钮权限
     * @param menuName
     * @param btnName
     */
    checkBtn(menuName: string, btnName: string): boolean {
        return this.menuService.checkBtn(menuName, btnName);
    }
}

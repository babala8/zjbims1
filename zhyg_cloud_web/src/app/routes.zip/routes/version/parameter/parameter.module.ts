import {NgModule} from '@angular/core';
import {SharedModule} from '@shared/shared.module';
import {VersionRoutingModule} from '../version.routing';
import {ParameterComponent} from './parameter.components';
import {ParameterService} from './parameter.service';

@NgModule({
    imports: [
        SharedModule,
        VersionRoutingModule,
    ],
    declarations: [
        ParameterComponent,
    ],
    entryComponents: [
    ],
    providers: [
        ParameterService
    ]
})
export class ParameterModule {

}

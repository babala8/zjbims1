import {NgModule} from '@angular/core';
import {SharedModule} from '@shared/shared.module';
import {VersionRoutingModule} from '../version.routing';
import {AdvertisementComponent} from './advertisement.components';
import {AdvertisementService} from './advertisement.service';
import {AdvertisementManageComponent} from './component/advertisement-manage.component';
import {AdvertisementMaintainComponent} from './component/advertisement-maintain.component';
import {AdvertisementLaunchComponent} from './component/advertisement-launch.component';
import {AdvertisementAddComponent} from './component/advertisement-add.component';
import {AdvertisementModifyComponent} from './component/advertisement-modify.component';
import {AdvertisementDetailComponent} from './component/advertisement-detail.component';
import {AdvertisementConfigureComponent} from './component/advertisement-configure.component';
import {AdvertisementLaunchDetailComponent} from './component/advertisement-launchDetail.component';
import {AdvertisementLaunchListComponent} from './component/advertisement-launchList.component';
import {AdvertisementPreviewComponent} from './component/advertisement-preview.component';

@NgModule({
    imports: [
        SharedModule,
        VersionRoutingModule,
    ],
    declarations: [
        AdvertisementComponent,
        AdvertisementManageComponent,
        AdvertisementMaintainComponent,
        AdvertisementLaunchComponent,
        AdvertisementAddComponent,
        AdvertisementModifyComponent,
        AdvertisementDetailComponent,
        AdvertisementConfigureComponent,
        AdvertisementLaunchDetailComponent,
        AdvertisementLaunchListComponent,
        AdvertisementPreviewComponent
    ],
    entryComponents: [
        AdvertisementManageComponent,
        AdvertisementMaintainComponent,
        AdvertisementLaunchComponent,
        AdvertisementAddComponent,
        AdvertisementModifyComponent,
        AdvertisementDetailComponent,
        AdvertisementConfigureComponent,
        AdvertisementLaunchDetailComponent,
        AdvertisementLaunchListComponent,
        AdvertisementPreviewComponent
    ],
    providers: [
        AdvertisementService
    ]
})
export class AdvertisementModule {

}

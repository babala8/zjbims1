import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'advertisement-preview',
    templateUrl: './advertisement-preview.html',
})
export class AdvertisementPreviewComponent implements OnInit {

    constructor(
    ) {
    }

    ngOnInit() {

    }

    refreshData() {

    }

}

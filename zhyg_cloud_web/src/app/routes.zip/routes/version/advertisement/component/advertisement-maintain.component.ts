import {Component, OnInit} from '@angular/core';
import {AdvertisementService} from '../../../version/advertisement/advertisement.service';
import {NzMessageService, NzModalService} from 'ng-zorro-antd';
import {HttpResponse} from '@angular/common/http';
import {AdvertisementDetailComponent} from '../../../version/advertisement/component/advertisement-detail.component';
import {AdvertisementPreviewComponent} from '../../../version/advertisement/component/advertisement-preview.component';
import {AdvertisementConfigureComponent} from '../../../version/advertisement/component/advertisement-configure.component';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
    selector: 'advertisement-maintain',
    templateUrl: './advertisement-maintain.html',
})
export class AdvertisementMaintainComponent implements OnInit {
    dataSet = [];
    validateForm: FormGroup;
    advertisementNameList = [];
    loading = false;

    constructor(
        private fb: FormBuilder,
        private advertisementService: AdvertisementService,
        private message: NzMessageService,
        private modal: NzModalService,
    ) {
    }

    refreshData(reset = false) {
        if (reset) {

        }
        this.loading = true;

        const params = {
            advertisementName: this.validateForm.controls.advertisementName.value || '',
        };
        this.advertisementService.getAdvertisement(params)
            .subscribe(_data => {
                console.log(_data);
                this.dataSet = _data['retList'];
                this.loading = false;
            }, (error) => {
                this.loading = false;
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    search() {
        this.refreshData(true);
    }

    ngOnInit(): void {
        this.validateForm = this.fb.group({
            advertisementName: [null, Validators.maxLength(20)],

        });
        this.advertisementService.getAdvertisementName({}).subscribe(
            data => {
                this.advertisementNameList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.refreshData(true);

    }

    showDetail(ad) {
        const modal = this.modal.open({
            title: '广告详情',
            maskClosable: false,
            footer: false,
            content: AdvertisementDetailComponent,
            componentParams: {
                ad: ad
            },
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

    showPreview(ad) {
        const modal = this.modal.open({
            title: '广告预览',
            maskClosable: false,
            footer: false,
            content: AdvertisementPreviewComponent,
            componentParams: {
                ad: ad
            },
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

    showConfigure(ad) {
        const modal = this.modal.open({
            title: '广告配置',
            maskClosable: false,
            footer: false,
            content: AdvertisementConfigureComponent,
            componentParams: {
                ad: ad
            },
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

}


import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {Ads} from '../../../../models/ads';
import {AdvertisementService} from '../advertisement.service';
import {NzMessageService, NzModalSubject} from 'ng-zorro-antd';
import {Router} from '@angular/router';
import {HttpResponse} from '@angular/common/http';

@Component({
    selector: 'advertisement-launchDetail',
    templateUrl: './advertisement-launchDetail.html',
})
export class AdvertisementLaunchDetailComponent implements OnInit {
    validateForm: FormGroup;
    loading = false;
    ads = new Ads;
    resourceTypeList = [];
    applyOrgList = [];
    applyDevTypeList = [];
    applyTradeList = [];
    choiceDevList = [];
    launchTypeList = [];
    launchCommandList = [];
    syn_startDate = null;
    syn_stopDate = null;
    syn_launchDate = null;

    constructor(private fb: FormBuilder,
                private advertisementService: AdvertisementService,
                private nzModal: NzModalSubject,
                private message: NzMessageService,
                private router: Router) {
    }


    _submitForm() {
        for (const i in this.validateForm.controls) {
            if (this.validateForm.controls[i]) {
                this.validateForm.controls[i].markAsDirty();
            }
        }
        if (this.validateForm.invalid) {
            return;
        }
        const params = {
            no: this.validateForm.controls.no.value,
            resourceType: this.validateForm.controls.resourceType.value,
            resource: this.validateForm.controls.resource.value,
            resolution: this.validateForm.controls.resolution.value,
            interval: this.validateForm.controls.interval.value,
            PrecisionMarketing: this.validateForm.controls.PrecisionMarketing.value,
            applyOrg: this.validateForm.controls.applyOrg.value,
            applyDevType: this.validateForm.controls.applyDevType.value,
            applyTrade: this.validateForm.controls.applyTrade.value,
            choiceDev: this.validateForm.controls.choiceDev.value,
            launchType: this.validateForm.controls.launchType.value,
            launchCommand: this.validateForm.controls.launchCommand.value,
            startDate: this.date2String(this.validateForm.controls.syn_startDate.value),
            launchDate: this.date2String(this.validateForm.controls.syn_launchDate.value),
        };

        console.log(params);
        this.loading = true;
        this.advertisementService.modifyAdvertisement(params)
            .subscribe(_data => {
                this.loading = false;
                this.message.success(`修改广告成功！`);
                this.nzModal.destroy('onOk');
                this.router.navigate(['/version/advertisement']);
            }, (error) => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    /**
     * 初始化表单
     */
    ngOnInit() {
        this.resourceTypeList = this.advertisementService.getResourceTypeInfo();
        this.launchTypeList = this.advertisementService.getLaunchTypeInfo();
        this.launchCommandList = this.advertisementService.getLaunchCommandInfo();
        this.advertisementService.getApplyOrg({}).subscribe(
            data => {
                this.applyOrgList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.advertisementService.getApplyDevType({}).subscribe(
            data => {
                this.applyDevTypeList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.advertisementService.getApplyTrade({}).subscribe(
            data => {
                this.applyTradeList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.validateForm = this.fb.group({
            no: [null],
            resourceType: [null],
            resource: [null],
            resolution: [null],
            interval: [null],
            PrecisionMarketing: [null],
            applyOrg: [null],
            applyDevType: [null],
            applyTrade: [null],
            choiceDev: [null],
            launchType: [null],
            launchCommand: [null],
            syn_startDate: [null],
            syn_stopDate: [null],
            syn_launchDate: [null],
        });

        // 获取广告详细信息
        this.loading = true;
        this.advertisementService.getAdvertisement({}).subscribe(
            data => {
                this.loading = false;
                console.log(data);
                this.ads = data;
                this.validateForm.controls.no.setValue(this.ads.no);
                this.validateForm.controls.resourceType.setValue(this.ads.resourceType);
                this.validateForm.controls.resource.setValue(this.ads.resource);
                this.validateForm.controls.resolution.setValue(this.ads.resolution);
                this.validateForm.controls.interval.setValue(this.ads.interval);
                this.validateForm.controls.PrecisionMarketing.setValue(this.ads.PrecisionMarketing);
                this.validateForm.controls.applyOrg.setValue(this.ads.applyOrg);
                this.validateForm.controls.applyDevType.setValue(this.ads.applyDevType);
                this.validateForm.controls.applyTrade.setValue(this.ads.applyTrade);
                this.validateForm.controls.syn_startDate.setValue(this.string2Date(this.ads.startDate));
                this.validateForm.controls.syn_stopDate.setValue(this.string2Date(this.ads.stopDate));

            },
            error => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    /**
     * 根据字段名获取表单字段值
     * @param name
     */
    getFormControl(name) {
        return this.validateForm.controls[name];
    }

    /**
     * 日期和字符串相互转换
     * @param date
     */
    date2String(date: Date): string {
        if (!date) {
            date = new Date();
        }
        const _date = date.toISOString().substring(0, 10);
        return _date;
    }

    string2Date(str: string): Date {
        return new Date(str.replace(/-/g, '/'));
    }

    cancel() {
        this.nzModal.destroy('onCancel');
    }
}

import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {AdvertisementService} from '../advertisement.service';
import {NzMessageService, NzModalService} from 'ng-zorro-antd';
import {HttpResponse} from '@angular/common/http';
import {AdvertisementAddComponent} from './advertisement-add.component';
import {AdvertisementModifyComponent} from './advertisement-modify.component';

@Component({
    selector: 'advertisement-configure',
    templateUrl: './advertisement-configure.html',
})
export class AdvertisementConfigureComponent implements OnInit {
    dataSet = [];
    validateForm: FormGroup;
    resourceTypeList = [];
    statusList = [];
    loading = false;

    constructor(
        private fb: FormBuilder,
        private advertisementService: AdvertisementService,
        private message: NzMessageService,
        private modal: NzModalService,
    ) {
    }

    refreshData(reset = false) {
        if (reset) {

        }
        this.loading = true;

        const params = {
            resourceType: this.validateForm.controls.resourceType.value || '',
            status: this.validateForm.controls.status.value || '',
        };
        this.advertisementService.getAdvertisementDetail(params)
            .subscribe(_data => {
                console.log(_data);
                this.dataSet = _data['retList'];
                this.loading = false;
            }, (error) => {
                this.loading = false;
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    search() {
        this.refreshData(true);
    }

    ngOnInit(): void {
        this.validateForm = this.fb.group({
            advertisementName: [null, Validators.maxLength(20)],

        });
        this.advertisementService.getAdvertisementResourceType({}).subscribe(
            data => {
                this.resourceTypeList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.advertisementService.getAdvertisementStatus({}).subscribe(
            data => {
                this.statusList = data.retList;
            }, error => {
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.refreshData(true);
    }

    addAdvertisement() {
        const modal = this.modal.open({
            title: '新增广告',
            maskClosable: false,
            footer: false,
            content: AdvertisementAddComponent,
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

    modifyAdvertisement(ad) {
        const modal = this.modal.open({
            title: '修改广告',
            maskClosable: false,
            footer: false,
            content: AdvertisementModifyComponent,
            componentParams: {
                ad: ad
            },
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

    deleteAdvertisement(ad) {
        this.advertisementService.deleteAdvertisement(ad.no).subscribe(r => {
            this.message.success(
                `广告${ad.no}删除成功！`
            );
            this.refreshData(true);
        }, (error) => {
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

}

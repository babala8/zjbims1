import {Component, OnInit } from '@angular/core';

@Component({
    templateUrl: './advertisement.html',
})
export class AdvertisementComponent implements OnInit {

    constructor(
    ) {
    }

    ngOnInit(): void {

    }
}

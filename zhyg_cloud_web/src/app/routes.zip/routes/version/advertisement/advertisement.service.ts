import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '@env/environment';
import {Location} from '@angular/common';
import {Observable} from 'rxjs/Observable';

@Injectable()
export class AdvertisementService {

    private advertisementUrl = `${environment.SERVER_URL}` + '/shepherd/app';

    constructor(
        private http: HttpClient,
        private location: Location
    ) {
    }

    /**
     * 资源类型
     */
    resourceTypeInfo = [
        {no: '1', name: '图片'},
        {no: '2', name: '视频'},
        {no: '3', name: '文字'},
        {no: '4', name: '链接'}
    ];

    /**
     * 广告投放时机
     */
    launchTypeInfo = [
        {no: '1', name: '立即投放'},
        {no: '2', name: '指定时间投放'}
    ]

    /**
     * 广告投放命令
     */
    launchCommandInfo = [
        {no: '1', name: '投放试运行设备'},
        {no: '2', name: '投放所有适用设备'},
        {no: '3', name: '取消投放'}
    ]

    getAdvertisement(params): Observable<any> {
        return this.http.post(this.advertisementUrl + '/qryAllAdvertisement', params);
    }

    getAdvertisementName(params): Observable<any> {
        return this.http.post(this.advertisementUrl + '/qryAllAdvertisementName', params);
    }

    getAdvertisementDetail(params): Observable<any> {
        return this.http.post(this.advertisementUrl + '/qryAllAdvertisementDetail', params);
    }

    getAdvertisementResourceType(params): Observable<any> {
        return this.http.post(this.advertisementUrl + '/qryAllAdvertisementResourceType', params);
    }

    /**
     * 获取广告状态
     */
    getAdvertisementStatus(params): Observable<any> {
        return this.http.post(this.advertisementUrl + '/qryAllAdvertisementStatus', params);
    }

    /**
     * 删除广告
     */
    deleteAdvertisement(no): Observable<any> {
        return this.http.post(this.advertisementUrl + '/delAdvertisement', {
            no: no
        });
    }

    /**
     * 添加广告
     */
    addAdvertisement(params): Observable<any> {
        return this.http.post(this.advertisementUrl + '/addAdvertisement', params);
    }

    /**
     * 修改广告
     */
    modifyAdvertisement(params): Observable<any> {
        return this.http.post(this.advertisementUrl + '/modifyAdvertisement', params);
    }

    /**
     * 获取资源类型
     */
    getResourceTypeInfo() {
        return this.resourceTypeInfo;
    }

    /**
     * 获取广告投放时机
     */
    getLaunchTypeInfo() {
        return this.launchTypeInfo;
    }

    /**
     * 获取广告投放命令
     */
    getLaunchCommandInfo() {
        return this.launchCommandInfo;
    }

    /**
     * 查询适用机构
     */
    getApplyOrg(params): Observable<any> {
        return this.http.post(this.advertisementUrl + '/qryApplyOrg', params);
    }

    /**
     * 查询适用设备类型
     */
    getApplyDevType(params): Observable<any> {
        return this.http.post(this.advertisementUrl + '/qryApplyDevType', params);
    }

    /**
     * 查询适用交易
     */
    getApplyTrade(params): Observable<any> {
        return this.http.post(this.advertisementUrl + '/qryApplyTrade', params);
    }

}


import {NgModule} from '@angular/core';
import {SysMenuService} from '../system/menu/menu.service';
import {VersionRoutingModule} from './version.routing';
import {AppstoreModule} from './appstore/appstore.module';
import {BenchmarkModule} from './benchmark/benchmark.module';
import {ParameterModule} from './parameter/parameter.module';
import {AdvertisementModule} from './advertisement/advertisement.module';

@NgModule({
    imports: [
        AppstoreModule,
        BenchmarkModule,
        ParameterModule,
        AdvertisementModule,
        VersionRoutingModule,
    ],
    providers: [
        SysMenuService
    ]
})
export class VersionModule {
    constructor() {
    }
}

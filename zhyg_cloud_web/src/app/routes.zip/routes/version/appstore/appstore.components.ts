import {AfterViewChecked, Component, OnInit} from '@angular/core';
import {Page} from '../../../models/page';
import {HttpResponse} from '@angular/common/http';
import {AppCatalog} from '../../../models/appCatalog';
import {AppstoreService} from './appstore.service';
import {NzMessageService, NzModalService, UploadFile} from 'ng-zorro-antd';
import {AppInfo} from '../../../models/appInfo';
import {AppVersion} from '../../../models/appVersion';
import {environment} from '@env/environment';
import {FileItem, FileUploader, ParsedResponseHeaders} from 'ng2-file-upload';
import {SessionService} from '@core/session.service';
import {RoleModifyComponent} from '../../system/role/component/role-modify.component';
import {AppModifyComponent} from './component/app-modify.component';
import {Router} from '@angular/router';
import {TitleService} from '@zjft/theme';
import {SysMenuService} from '../../system/menu/menu.service';

@Component({
    templateUrl: './appstore.html',
})
export class AppstoreComponent implements OnInit {

    formModel = {};
    loading = true;
    page = new Page();
    appCatalogs: AppCatalog[];
    appTypes;
    dataSet: AppInfo[] = [];
    uploadVisible = false;
    filePath;
    uploadDisable = true;
    description;
    fileName;
    devCatalogList;

    constructor(
        private appstoreService: AppstoreService,
        private message: NzMessageService,
        private session: SessionService,
        private modal: NzModalService,
        private menuService: SysMenuService,
    ) {
    }

    ngOnInit() {
        this.appstoreService.getDevCatalogs({}).subscribe(
            data => {
                this.devCatalogList = data.retList;
            },
            error => {
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.appTypes = this.appstoreService.getTypeTransfer();
        this.refreshData(true);
        // 获取应用分类信息
        this.appstoreService.getAppCatalogs({}).subscribe(
            data => {
                this.appCatalogs = data.retList;
            }, error => {
                console.log(error);
                this.appCatalogs = [];
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
    }

    refreshData(reset = false) {
        if (reset) {
            this.page.curPage = 1;
        }
        this.loading = true;
        const params = {
            appName: this.formModel['appName'] || '',
            appCatalog: this.formModel['appCatalog'] || '',
            appType: this.formModel['appType'] || '',
            curPage: this.page.curPage,
            pageSize: this.page.pageSize,
            // 暂时先使用列表方式
            showType: 'list',
        };
        console.log('appName:' + params.appName + 'appCatalog:' + params.appCatalog);

        // 获取应用列表
        this.appstoreService.getApps(params)
            .subscribe(data => {
                this.loading = false;
                if (data.retList) {
                    for (const i of data.retList) {
                        const devCatalog = (i as AppInfo).devCatalog;
                        (i as AppInfo).devCatalogName = devCatalog.substring(devCatalog.indexOf(',') + 1);
                    }
                    this.dataSet = data.retList;
                    // 将设备类型编号转换为名称
                    this.dataSet.map(x => {
                        const temp = x.devCatalog.split('|');
                        let name = '';
                        for (const j of temp) {
                            for (const i of this.devCatalogList) {
                                if (j === i.no) {
                                    name += ',' + i.name;
                                    break;
                                }
                            }
                        }
                        x.devCatalogName = name.substring(1);
                    });
                    this.page.totalRow = data['totalRow'];
                    // 默认化表格不展开
                    this.dataSet.map(x => x.expand = false);
                } else {
                    this.dataSet = [];
                }
            }, (error) => {
                this.loading = false;
                console.log(error);
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    /**
     * 删除应用
     * @param appId
     */
    confirmDel(appId) {
        this.appstoreService.delApp({
            appId: appId
        }).subscribe(data => {
            this.refreshData(false);
            this.message.success('删除应用成功');
            this.refreshData(false);
        }, (error) => {
            console.log(error);
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    /**
     * 禁用应用
     * @param appId
     * @param appStatus
     */
    confirmBan(appId, appStatus) {
        if (appStatus === '2') {
            appStatus = '1';
        } else {
            appStatus = '2';
        }
        this.appstoreService.banApp({
            appId: appId,
            appStatus: appStatus
        }).subscribe(data => {
            this.refreshData(false);
            this.message.success('禁用应用成功');
            this.refreshData(false);
        }, (error) => {
            console.log(error);
            if (error instanceof HttpResponse) {
                this.message.error(error.body.retMsg);
            }
        });
    }

    /**
     * 不能删
     */
    cancel() {

    }

    /**
     * 获取应用类型名称
     * @param no
     */
    getTypeName(no: string): string {
        return this.appstoreService.getTypeName(no);
    }

    /**
     * 展开应用详情表格
     * @param appId
     */
    showDetail(appId: string) {
        // 折叠时直接返回
        const temp: AppInfo[] = this.dataSet.filter(x => x.appId === appId && x.expand === true);
        if (temp && temp.length === 0) {
            return;
        }
        this.appstoreService.getVersions({appId: appId})
            .subscribe(
                data => {
                    for (const i of this.dataSet) {
                        if (i.appId === appId) {
                            i.versions = data.versionList;
                            break;
                        }
                    }
                }, error => {
                    if (error instanceof HttpResponse) {
                        this.message.error(error.body.retMsg);
                    }
                });
    }

    /**
     * 显示文件上传模态框
     */
    showUpload() {
        this.uploadVisible = true;
    }

    /**
     * 取消文件上传
     */
    cancelUpload() {
        this.uploadVisible = false;
        this.resetUpload();
    }

    /**
     * 重置上传组件
     */
    resetUpload() {
        this.loading = false;
        this.uploader.cancelAll();
        this.uploader.clearQueue();
        this.fileName = '';
    }

    /**
     * 上传文件配置
     */
    uploader: FileUploader = new FileUploader({
        url: `${environment.SERVER_FILE_URL}` + '/upload/versionUpload',
        method: 'POST',
        itemAlias: 'uploadedfile',
        autoUpload: false
    });

    /**
     * 选择文件后立即执行校验
     */
    checkFile(event) {
        if (!event.target.value) {
            return;
        }
        this.loading = true;
        // 成功处理回调函数
        this.uploader.onSuccessItem = (item, response, status, headers) => {
            const result = JSON.parse(response);
            console.log(result);
            if (!result.rspMsg.retCode.startsWith('A')) {
                this.message.error(result.rspMsg.retMsg);
                return;
            }
            // 获取ucp端的文件路径
            this.filePath = result.rspMsg.filePath;
            // 校验文件
            this.appstoreService.checkVersionFile({filePath: this.filePath}).subscribe(
                data => {
                    this.loading = false;
                    this.message.success(data.retMsg);
                    this.uploadDisable = false;
                }, error => {
                    this.loading = false;
                    this.message.error(error.body.retMsg);
                    this.resetUpload();
                }
            );
        };
        // 错误处理回调函数
        this.uploader.onErrorItem = (item, response, status, headers) => {
            const result = JSON.parse(response);
            this.message.error(result.rspMsg.retMsg);
            this.resetUpload();
        };
        this.uploader.uploadAll();
    }

    /**
     * 校验成功后版本入库
     */
    saveVersion() {
        this.appstoreService.saveVersionFile({
            filePath: this.filePath,
            userId: this.session.getUserSession().account,
            description: this.description
        }).subscribe(
            data => {
                this.loading = false;
                if (data.retCode.startsWith('A')) {
                    this.message.success(data.retMsg);
                    this.uploadDisable = true;
                    this.uploadVisible = false;
                    this.description = '';
                } else {
                    this.message.error(data.retMsg);
                }
            }, error => {
                this.loading = false;
                this.message.error(error.body.retMsg);
            }
        );
        this.resetUpload();
    }

    /**
     * 重置查询条件
     */
    resetSearch() {
        this.formModel = {};
        this.refreshData(true);
    }

    /**
     * 打开修改窗口
     * @param appName
     */
    modApp(appName: string) {
        this.modal.open({
            title: '修改应用',
            maskClosable: false,
            footer: false,
            content: AppModifyComponent,
            componentParams: {
                appName: appName
            },
            onOk: () => {
                this.refreshData(true);
            },
            onCancel: () => {
            }
        });
    }

    /**
     * 校验按钮权限
     * @param menuName
     * @param btnName
     */
    checkBtn(menuName: string, btnName: string): boolean {
        return this.menuService.checkBtn(menuName, btnName);
    }

}

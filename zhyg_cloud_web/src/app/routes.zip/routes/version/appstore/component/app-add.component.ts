import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NzMessageService, UploadFile} from 'ng-zorro-antd';
import {HttpResponse} from '@angular/common/http';
import {SessionService} from '@core/session.service';
import {Router} from '@angular/router';
import {AppstoreService} from '../appstore.service';
import {DevCatalog} from '../../../../models/devCatalog';

@Component({
    templateUrl: './app-add.html',
    styleUrls: ['./app-add.scss']
})
export class AppAddComponent implements OnInit {
    validateForm: FormGroup;
    loading = false;
    showFlag = 0;
    appTypeList = [];
    appCatalogList = [];
    devCatalogList: DevCatalog[];
    avatarUrl: string;
    logoPath;

    constructor(
        private fb: FormBuilder,
        private appstoreService: AppstoreService,
        private message: NzMessageService,
        private router: Router,
        private session: SessionService,
    ) {
    }

    /**
     * 初始化表单
     */
    ngOnInit() {
        this.appTypeList = this.appstoreService.getTypeTransfer();
        this.appstoreService.getAppCatalogs({}).subscribe(
            data => {
                this.appCatalogList = data.retList;
            },
            error => {
                this.appCatalogList = [];
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.appstoreService.getDevCatalogs({}).subscribe(
            data => {
                this.devCatalogList = data.retList;
            },
            error => {
                this.devCatalogList = [];
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            }
        );
        this.validateForm = this.fb.group({
            appId: [null, [Validators.required, Validators.maxLength(20)]],
            appName: [null, [Validators.required, Validators.maxLength(50)]],
            appType: [null, Validators.required],
            appCatalog: [null, [Validators.required]],
            devCatalog: [null],
            versionPath: [null],
            description: [null]
        });
    }

    submitForm() {
        // 执行表单校验
        for (const i in this.validateForm.controls) {
            this.validateForm.controls[i].markAsDirty();
        }

        if (this.validateForm.invalid) {
            return;
        }

        const params = {
            appId: this.validateForm.controls.appId.value,
            appName: this.validateForm.controls.appName.value,
            appType: this.validateForm.controls.appType.value,
            appCatalog: this.validateForm.controls.appCatalog.value,
            devCatalog: this.setDevCatalog(this.validateForm.controls.devCatalog.value),
            versionPath: this.validateForm.controls.versionPath.value || '',
            appLogo: this.logoPath || '',
            description: this.validateForm.controls.description.value || '',
            userId: this.session.getUserSession().account,
        };

        console.log(params);
        this.loading = true;
        this.appstoreService.addApp(params)
            .subscribe(data => {
                this.loading = false;
                this.message.success(`添加应用成功！`);
                this.router.navigateByUrl('/version/appstore');
            }, (error) => {
                this.loading = false;
                if (error instanceof HttpResponse) {
                    this.message.error(error.body.retMsg);
                }
            });
    }

    /**
     * 根据字段名获取表单字段值
     * @param name
     */
    getFormControl(name) {
        return this.validateForm.controls[name];
    }

    cancel() {
        this.appstoreService.back();
    }

    /**
     * 处理设备类型入库的值
     * @param list
     */
    private setDevCatalog(list: string[]): string {
        if (list.length === 0) {
            return '';
        }
        list = list.sort((a: string, b: string) => a > b ? 1 : -1);
        let temp = '';
        for (const i of list) {
            temp += '|' + i;
        }
        return temp.substring(1);
    }

    /**
     * 校验图片格式和大小
     * @param file
     */
    beforeUpload = (file: File) => {
        this.logoPath = file.name;
        const checkType = file.type === 'image/jpeg' || file.type === 'image/png';
        if (!checkType) {
            this.message.error('只能上传jpg或png格式的图片！');
        }
        const checkSize = file.size / 1024 / 1024 < 2;
        if (!checkSize) {
            this.message.error('图片必须小于2M！');
        }
        return checkType && checkSize;
    };

    private getBase64(img: File, callback: (img: any) => void) {
        const reader = new FileReader();
        reader.addEventListener('load', () => callback(reader.result));
        reader.readAsDataURL(img);
    }

    handleChange(info: { file: UploadFile }) {
        if (info.file.status === 'uploading') {
            this.loading = true;
            return;
        }
        if (info.file.status === 'done') {
            this.getBase64(info.file.originFileObj, (img: any) => {
                this.loading = false;
                this.avatarUrl = img;
            });
        }
    }

}


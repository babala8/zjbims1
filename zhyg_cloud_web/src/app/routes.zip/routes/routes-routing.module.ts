import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {environment} from '@env/environment';
// layout
import {LayoutDefaultComponent} from '../layout/default/default.component';
import {LayoutMetroComponent} from '../layout/metro/layout.metro.component';

// single pages
import {CallbackComponent} from './callback/callback.component';
import {Exception403Component} from './exception/403.component';
import {Exception404Component} from './exception/404.component';
import {Exception500Component} from './exception/500.component';
import {DemoDashboardComponent} from './dashboard/dashboard.component';
import {LoginComponent} from './login/login.component';
import {PasswordComponent} from './login/password.component';
import {LoginGuard} from '@core/guard/login-guard.service';
import {AuthGuard} from '@core/guard/auth-guard.service';

const routes: Routes = [
    {
        path: '',
        // component: LayoutDefaultComponent,
        component: LayoutMetroComponent,
        // canActivate: [LoginGuard],
        // canActivateChild: [AuthGuard],
        children: [
            {path: '', redirectTo: 'dashboard', pathMatch: 'full'},
            // { path: 'dashboard', redirectTo: 'dashboard/v1', pathMatch: 'full' },
            {path: 'dashboard', component: DemoDashboardComponent},
            // { path: 'dashboard/analysis', component: DashboardAnalysisComponent },
            // { path: 'dashboard/monitor', component: DashboardMonitorComponent },
            // { path: 'dashboard/workplace', component: DashboardWorkplaceComponent },
            {path: 'system', loadChildren: './system/system.module#SystemModule'},
            {path: 'version', loadChildren: './version/version.module#VersionModule'}
        ]
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'password/:userNo',
        component: PasswordComponent
    },
    // 单页不包裹Layout
    {path: 'callback/:type', component: CallbackComponent},
    {path: '403', component: Exception403Component},
    {path: '404', component: Exception404Component},
    {path: '500', component: Exception500Component},
    {path: '**', redirectTo: 'dashboard'}
];

@NgModule({
    imports: [RouterModule.forRoot(routes, {useHash: environment.useHash})],
    exports: [RouterModule]
})
export class RouteRoutingModule {
}

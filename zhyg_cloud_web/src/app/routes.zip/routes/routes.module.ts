import {NgModule} from '@angular/core';
import {SharedModule} from '@shared/shared.module';
import {RouteRoutingModule} from './routes-routing.module';
import {CallbackComponent} from './callback/callback.component';
import {Exception403Component} from './exception/403.component';
import {Exception404Component} from './exception/404.component';
import {Exception500Component} from './exception/500.component';
import {DemoDashboardComponent} from './dashboard/dashboard.component';
import {LoginComponent} from './login/login.component';
import {PasswordComponent} from './login/password.component';
import {HeaderModule} from '../layout/metro/header/header.module';
import {HeaderMenuComponent} from '../layout/metro/header/components/menu/menu.component';

@NgModule({
    imports: [
        SharedModule,
        RouteRoutingModule,
        HeaderModule,
        // ZjDashboardModule.forRoot(DemoDashboardService),
    ],
    declarations: [
        DemoDashboardComponent,
        CallbackComponent,
        Exception403Component,
        Exception404Component,
        Exception500Component,
        LoginComponent,
        PasswordComponent,
    ],
    providers: [
        HeaderMenuComponent,
    ]
})

export class RoutesModule {
}

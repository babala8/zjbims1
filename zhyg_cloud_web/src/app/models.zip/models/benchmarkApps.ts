export class BenchmarkApps {
    constructor(
        public appsId?: string,
        public appsName?: string,
        public versionBusNo?: string,
        public versionNo?: string,
        public selected: boolean = false,
        public updateMode?: string,
        public synMode?: string,
        public description?: string
    ) {
    }
}

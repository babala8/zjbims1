export class AppCatalog {
    constructor(
        public no?: string,
        public name?: string
    ) {
    }
}

import {AppVersion} from './appVersion';

export class AppInfo {
    constructor(
        public appId?: string,
        public appName?: string,
        public appType?: string,
        public appCatalog?: string,
        public appCatalogName?: string,
        public devCatalog?: string,
        public devCatalogName?: string,
        public orgNoList?: string,
        public appStatus?: string,
        public versionPath?: string,
        public logoPath?: string,
        public addUser?: string,
        public addTime?: string,
        public description?: string,
        public expand?: boolean,
        public versions?: AppVersion[]
    ) {
    }
}

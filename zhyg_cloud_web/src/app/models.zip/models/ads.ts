export class Ads {
    constructor(public no?: string,
                public resourceType?: string,
                public resource?: string,
                public resolution?: string,
                public interval?: string,
                public PrecisionMarketing?: string,
                public applyOrg?: string,
                public applyDevType?: string,
                public applyTrade?: string,
                public startDate?: string,
                public stopDate?: string,
                public launchDate?: string,
    ) {

    }
}

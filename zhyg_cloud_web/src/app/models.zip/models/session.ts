
export class Session {

    constructor(public account?: string,
                public name?: string,
                public orgGrade?: string,
                public orgName?: string,
                public orgNo?: string,
                public roleCatalog?: number,
                public view?: string) {
    }
}

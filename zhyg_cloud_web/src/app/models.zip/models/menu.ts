export class Menu {
    no: string;
    name: string;
    uRL?: string;
    level?: number;
    order?: number;
    note?: string;
    shape?: string;
    subMenu?: Menu[];
    superMenu?: Menu;
    // buttons?: [];
}
